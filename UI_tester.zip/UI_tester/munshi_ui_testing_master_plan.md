# Munshi Invoice Listing Page — UI Testing Agent
## Master Plan: Playwright + Cucumber (BDD) Architecture

> **Source of truth**: `listing_page_staging_reference.pdf` (origin/staging @ ec431c8)
> **Goal**: An automated agent that runs on demand and verifies every behaviour described
> in the PDF, reports deviations clearly, and can be plugged into CI/CD.

---

## 1. Why Playwright + Cucumber?

| Concern | Playwright | Cucumber |
|---|---|---|
| Real browser automation | Yes (Chromium/Firefox/WebKit) | — |
| SSE / WebSocket support | Native | — |
| Intercept/mock APIs | Yes (route intercept) | — |
| Human-readable specs | — | Gherkin scenarios |
| Business traceability | — | Scenarios map 1-to-1 to PDF sections |
| Parallel execution | Yes (sharding) | Supported via tags |
| Reports | Built-in HTML + Allure | Cucumber HTML report |
| TypeScript support | First-class | Yes |

**Recommendation**: Use **TypeScript** throughout. Strongly typed fixtures and page objects
reduce false negatives due to misnamed selectors.

---

## 2. Recommended Tech Stack

```
Language:      TypeScript
Test runner:   Playwright Test (with @cucumber/cucumber adapter OR
               playwright-bdd library — see section 4)
BDD parser:    @cucumber/cucumber (or playwright-bdd)
Reporter:      @cucumber/html-formatter + Allure (optional)
Linter:        ESLint + Prettier
CI:            GitHub Actions (or any CI runner)
Node:          ≥ 18 LTS
```

### Which adapter to choose?

**Option A — `playwright-bdd` (Recommended)**
- Wraps Playwright Test natively; you get fixtures, parallelism, retries, Playwright
  HTML report, and Gherkin all in one.
- Install: `npm i -D playwright-bdd`

**Option B — `@cucumber/cucumber` with Playwright**
- Uses Cucumber JS runner with Playwright as the browser library.
- More familiar if your team already uses Cucumber JS.
- Loses some Playwright-native features (e.g. trace viewer, built-in retry).

This plan is written for **Option A** but the feature files work for both.

---

## 3. Project Folder Structure

```
ui-tester/
│
├── features/                        # Gherkin feature files (1 per PDF section)
│   ├── 01_page_anatomy.feature
│   ├── 02_invoice_types.feature
│   ├── 03_header_controls.feature
│   │   ├── 03a_company_dropdown.feature
│   │   ├── 03b_notification_bell.feature
│   │   ├── 03c_tally_connection.feature
│   │   └── 03d_upload_invoice_button.feature
│   ├── 04_tally_status_tabs.feature
│   ├── 05_filter_bar.feature
│   │   ├── 05a_search.feature
│   │   └── 05b_date_filter.feature
│   ├── 06_actions_menu.feature
│   │   ├── 06a_download.feature
│   │   ├── 06b_transfer.feature
│   │   ├── 06c_mark_duplicate.feature
│   │   ├── 06d_reject_invoices.feature
│   │   └── 06e_delete.feature
│   ├── 07_tally_push_button.feature
│   ├── 08_table_columns.feature
│   ├── 09_status_badges.feature
│   ├── 10_selection_model.feature
│   ├── 11_pagination.feature
│   ├── 12_upload_dialog.feature
│   ├── 13_row_lifecycle.feature
│   ├── 14_rbac_permissions.feature
│   ├── 15_state_persistence.feature
│   └── 16_known_gaps.feature       # Documents known bugs (O1-O11) as skipped/xfail
│
├── steps/                           # Step definitions (TypeScript)
│   ├── common.steps.ts              # Shared steps (navigation, login, waits)
│   ├── header.steps.ts
│   ├── tabs.steps.ts
│   ├── filter.steps.ts
│   ├── actions.steps.ts
│   ├── push.steps.ts
│   ├── table.steps.ts
│   ├── upload.steps.ts
│   └── lifecycle.steps.ts
│
├── pages/                           # Page Object Model (POM)
│   ├── ListingPage.ts               # Main POM for the listing
│   ├── UploadModal.ts               # Upload dialog POM
│   ├── TransferDialog.ts
│   ├── PushPanel.ts                 # Floating "Pushing to Tally" panel
│   └── components/
│       ├── Header.ts
│       ├── NotificationBell.ts
│       ├── TallyConnectionPopup.ts
│       ├── DateFilterPopover.ts
│       └── ActionsMenu.ts
│
├── fixtures/                        # Test data and file fixtures
│   ├── invoices/
│   │   ├── purchase_invoice.pdf     # For item-wise purchase test
│   │   ├── sales_invoice.pdf
│   │   ├── credit_note.pdf
│   │   ├── debit_note.pdf
│   │   └── expense_invoice.pdf
│   ├── users.ts                     # Owner + sub-user credentials per right
│   └── seed.ts                      # Seed script: creates fresh company + uploads
│
├── helpers/
│   ├── api.helper.ts                # Direct API calls (setup/teardown via REST)
│   ├── sse.helper.ts                # SSE listener for real-time event assertions
│   ├── storage.helper.ts            # Read/write sessionStorage + localStorage
│   └── wait.helper.ts               # Smart waits (poll until status changes)
│
├── support/
│   ├── world.ts                     # Cucumber World (or Playwright fixture)
│   ├── hooks.ts                     # Before/After hooks
│   └── tags.ts                      # Tag constants (@smoke, @regression, etc.)
│
├── playwright.config.ts
├── cucumber.config.ts               # (if using Option B)
├── tsconfig.json
└── package.json
```

---

## 4. Page Object Model — Key Design Decisions

### ListingPage.ts (Core POM)

The listing page POM should expose these logical groups:

```typescript
class ListingPage {
  // Navigation
  goto(companyId: string): Promise<void>

  // Header
  header: Header  // sub-POM

  // Tabs
  clickTab(tab: 'All' | 'Ready to Push' | 'Pushing to Tally' | 'Pushed' | 'Failed')
  getTabCount(tab: TabName): Promise<number>
  getActiveTab(): Promise<TabName>

  // Filter bar
  search(query: string): Promise<void>
  openDateFilter(): Promise<DateFilterPopover>
  getSelectedCount(): Promise<number>
  openActionsMenu(): Promise<ActionsMenu>

  // Push button
  getTallyPushButton(): Locator
  getTallyPushLabel(): Promise<string>
  isTallyPushVisible(): Promise<boolean>
  isTallyPushEnabled(): Promise<boolean>
  clickTallyPush(): Promise<void>

  // Table
  getRows(): Promise<RowInfo[]>
  getRow(name: string): Promise<RowInfo>
  selectRow(name: string): Promise<void>
  selectAllOnPage(): Promise<void>
  clickRow(name: string): Promise<void>

  // Columns
  sortBy(column: SortableColumn): Promise<void>
  getColumnValues(column: string): Promise<string[]>
  getInvoiceTypeFilter(): Promise<InvoiceTypeFilterPopover>
  getStatusFilter(): Promise<StatusFilterPopover>
  getTallyStatusFilter(): Promise<TallyStatusFilterPopover>

  // Pagination
  getPageInfo(): Promise<{ from: number; to: number; total: number }>
  setRowsPerPage(n: 10 | 20 | 30 | 40 | 50): Promise<void>
  nextPage(): Promise<void>
  prevPage(): Promise<void>

  // Floating panels
  getUploadPanel(): UploadPanel
  getPushPanel(): PushPanel

  // Toast helper
  waitForToast(text: string | RegExp): Promise<string>
}
```

### RowInfo type

```typescript
interface RowInfo {
  id: string
  name: string
  invoiceNo: string
  invoiceDate: string
  sellerName: string
  amount: string
  uploadDate: string
  invoiceType: InvoiceType   // 'Purchase' | 'Sales' | 'Credit Note' | 'Debit Note' | 'Expense'
  status: ProcessingStatus   // 'Processing' | 'Ready to Review' | 'Reviewed' | ...
  tallyStatus: TallyStatus   // 'Extracting Data' | 'Ready to Push' | 'Pushing' | 'Pushed' | 'Failed' | 'N/A'
  isSelectable: boolean
  isClickable: boolean
  badgeColor: string
}
```

---

## 5. Feature Files — Key Scenarios

Below are the most important scenarios, mapped directly to the PDF. These are the
ones the agent MUST verify.

### 5.1 Tally Status Tabs (`04_tally_status_tabs.feature`)

```gherkin
Feature: Tally Status Tabs
  # PDF Section 5

  Background:
    Given I am logged in as the owner
    And I am on the Invoice Listing page for "Test Company"

  Scenario: Tab counts are independent of filters
    Given the page has 5 "Ready to Review" invoices and 3 "Reviewed" invoices
    When I search for a specific invoice name that matches only 1 result
    Then the "Ready to Push" tab count should still show 5
    And the "Failed" tab count should be unaffected

  Scenario: All tab hides Tally Push and Actions menu items
    When I click the "All" tab
    Then the "Tally Push" button should not be visible
    And "Mark as Duplicate" should not be visible in the Actions menu
    And "Reject Invoices" should not be visible in the Actions menu

  Scenario: Pushing tab disables the Tally Push button
    Given at least one invoice is pushing
    When I click the "Pushing to Tally" tab
    Then the "Tally Push" button should be visible but disabled
    And the tab should show a spinner

  Scenario: Pushed tab shows Re Push label
    Given at least one invoice has been pushed
    When I click the "Pushed" tab
    And I select a row
    Then the push button label should be "Re Push to Tally (1)"

  Scenario: Failed tab includes duplicates, rejected and OCR-failed rows
    Given there are duplicate, rejected, and ocr_failed invoices
    When I click the "Failed" tab
    Then all three types of rows should appear in the table
    And the tab count should include all three types

  Scenario: Clicking a tab resets page to 1 and clears Tally Status filter
    Given I am on page 3 with Tally Status filter "Pushed"
    When I click the "Ready to Push" tab
    Then I should be on page 1
    And the Tally Status column filter should show "All"
```

### 5.2 Upload Invoice (`12_upload_dialog.feature`)

```gherkin
Feature: Upload Invoice Dialog
  # PDF Section 13

  Scenario Outline: Upload with each voucher type shows correct badge
    Given I open the Upload Invoice dialog
    When I upload "<file>" with voucher type "<type>"
    Then the row should appear with badge color "<color>"
    And the Invoice Type filter should include "<type>"

    Examples:
      | file                 | type         | color  |
      | purchase_invoice.pdf | Purchase     | blue   |
      | sales_invoice.pdf    | Sales        | green  |
      | credit_note.pdf      | Credit Note  | amber  |
      | debit_note.pdf       | Debit Note   | red    |
      | expense_invoice.pdf  | Expense      | purple |

  Scenario: Upload a duplicate file
    Given I have already uploaded "purchase_invoice.pdf"
    When I upload "purchase_invoice.pdf" again
    Then the row status should start as "Duplicate · Extracting"
    And eventually become "Duplicate"
    And an error toast should appear mentioning "detected as a duplicate invoice"
    And clicking the row should open the review screen normally

  Scenario: Cannot switch mode when files are selected
    Given I have selected 2 files in Single mode
    When I try to switch to Multiple mode
    Then the mode toggle should be disabled
    And a tooltip should say "Remove all files to switch mode"

  Scenario: Upload button disabled with missing voucher type
    Given I have added a file without selecting a voucher type
    When I look at the Upload button
    Then it should be disabled
    And the voucher type field should show "Please select a voucher type for all invoices"
```

### 5.3 Tally Push Button (`07_tally_push_button.feature`)

```gherkin
Feature: Tally Push / Re Push Button
  # PDF Section 8

  Scenario: Push button shows error for 51+ selected rows
    Given I am on "Ready to Push" tab
    And I have selected 51 rows
    When I click the "Tally Push" button
    Then I should see error toast "Select between 1 and 50 files to push to Tally"
    And no push API calls should have been made

  Scenario: Push flow with confirm dialog
    Given the browser has NOT stored "tallyPushDontAskAgain"
    And I have selected 2 invoices on "Ready to Push" tab
    When I click "Tally Push (2)"
    Then the confirm dialog should appear with text about unreviewed invoices
    And the dialog should have a "Don't ask again" checkbox
    When I click "Push anyway"
    Then the 2 rows should immediately show "Pushing to Tally" status
    And the "Pushing to Tally" panel should appear at the bottom right

  Scenario: Push skips dialog when Don't ask again is stored
    Given localStorage has "tallyPushDontAskAgain" = "true"
    And I have selected 1 invoice
    When I click "Tally Push (1)"
    Then the confirm dialog should NOT appear
    And the push should proceed immediately

  Scenario: Push result — success row
    Given I pushed an invoice that Tally accepts
    When the push completes
    Then the row status should be "Reviewed"
    And the row Tally status should be "Pushed"
    And the panel row should show "Synced to Tally"

  Scenario: Push result — all fail, no summary toast
    Given I pushed 2 invoices that both fail in Tally
    When the push completes
    Then no summary toast should appear
    And both rows should show "Failed" Tally status
    And the Tally errors should appear in the notification bell

  Scenario: Push result — mixed
    Given I pushed 3 invoices where 2 succeed and 1 fails
    When the push completes
    Then a toast should say "2 pushed, 1 failed"
```

### 5.4 Actions Menu (`06_actions_menu.feature`)

```gherkin
Feature: Actions Menu — Bulk Actions
  # PDF Section 7

  Scenario: Actions menu is hidden with no selection
    Given I have no rows selected
    Then the Actions menu should not be visible

  Scenario: Actions menu appears when rows are selected
    Given I select 1 row
    Then the Actions menu dropdown should be visible

  Scenario: Mark as Duplicate not shown on All tab
    Given I select a row
    And I am on the "All" tab
    When I open the Actions menu
    Then "Mark as Duplicate" should not be in the menu

  Scenario: Mark as Duplicate not shown on Failed tab
    Given I select a row on the "Failed" tab
    When I open the Actions menu
    Then "Mark as Duplicate" should not be in the menu

  Scenario: Mark as Duplicate shown on Ready to Push tab
    Given I select a "Ready to Review" invoice on "Ready to Push" tab
    When I open the Actions menu
    Then "Mark as Duplicate" should be in the menu
    When I click "Mark as Duplicate"
    Then a confirm dialog should appear
    When I confirm
    Then the row status should become "Duplicate"
    And a toast should say "1 invoice(s) marked as duplicate"

  Scenario: Download — single invoice
    Given I select exactly 1 invoice
    When I click Actions → Download
    Then a file download should start for that invoice's original file
    And a toast should appear "Invoice downloaded successfully"

  Scenario: Download — bulk
    Given I select 3 invoices
    When I click Actions → Download
    Then a ZIP download named "invoices.zip" should start
    And a toast should say "3 invoices downloaded as ZIP"

  Scenario: Transfer requires right transfer_invoice
    Given I am logged in as a sub-user WITHOUT "transfer_invoice" right
    And I select a row
    When I open the Actions menu
    Then "Transfer" should not be in the menu

  Scenario: Delete with right delete_invoice
    Given I am logged in as a user WITH "delete_invoice" right
    And I select 2 invoices
    When I click Actions → Delete
    Then the confirmation dialog should say "delete 2 selected invoice(s)"
    When I confirm deletion
    Then the 2 rows should disappear from the table
    And a toast should say "2 invoice(s) deleted successfully"
```

### 5.5 Filter Bar (`05_filter_bar.feature`)

```gherkin
Feature: Filter Bar — Search and Date Filter
  # PDF Sections 6.1, 6.2

  Scenario: Search is case-insensitive and resets to page 1
    Given I am on page 3
    When I type "ACME" in the search box
    Then only rows containing "acme" (case-insensitive) should be shown
    And I should be back on page 1

  Scenario: Date filter — Invoice Date range excludes missing dates
    When I set date type "Invoice Date" and range "Last 7 Days"
    Then only rows whose invoice date falls in the last 7 days should show
    And rows with no invoice date should be excluded

  Scenario: Date filter — All Dates with Reviewed type shows only reviewed invoices
    When I set date type "Reviewed Date" and range "All Dates"
    Then only invoices with Reviewed status should be shown

  Scenario: Custom date range — From cannot be after To
    When I open the date filter and set Custom Range
    And I set From to "2026-11-01"
    And I set To to "2026-10-01"
    Then the To field should be cleared automatically

  Scenario: Date filter is client-side only
    Given the network is monitored
    When I change the date filter
    Then no new API call to /api/invoice/list should be made

  Scenario: All column filters combine with each other and the tab
    Given I am on "Ready to Push" tab
    When I filter Invoice Type = "Expense"
    And I set Status = "Reviewed"
    And I search for "supplier"
    Then the table should show rows matching ALL three conditions simultaneously
    And each filter change should reset to page 1
```

### 5.6 Table Columns and Sorting (`08_table_columns.feature`)

```gherkin
Feature: Table Columns and Sorting
  # PDF Section 9

  Scenario: Sort cycles desc → asc → off
    When I click the "File Name" column header once
    Then rows should be sorted A-Z (wait, desc = Z-A first)
    When I click it again
    Then rows should be sorted Z-A (asc = A-Z)
    When I click it again
    Then rows should be in server order (newest upload first)

  Scenario: Invoice No column sorts numerically
    Given invoices with numbers "2", "10", "100", "3" exist
    When I sort by "Invoice No"
    Then the order should be 100, 10, 3, 2 (descending numeric)

  Scenario: Switching sort column resets to descending
    Given "File Name" column is sorted ascending
    When I click "Amount" column header
    Then "Amount" should be sorted descending (not ascending)

  Scenario: Sort state is not remembered after refresh
    Given I sort by "Upload Date" descending
    When I refresh the page
    Then the table should be in server order (no sort active)

  Scenario: Copy Invoice Details clipboard
    When I click the clipboard icon on a row
    Then the clipboard should contain lines for:
      | Invoice ID   |
      | Invoice Number |
      | Invoice Date  |
      | Invoice Type  |
      | Company ID    |
      | Company Name  |
      | File Name     |
      | Status        |
      | Tally Status  |
    And the icon should show a tick for 2 seconds
    And the row should NOT open

  Scenario: Processing rows cannot be selected or opened
    Given a row is in "Processing" (uploaded/in_process) status
    Then its checkbox should be disabled
    And clicking the row should do nothing (cursor: default)
    And the trash icon for that row should be disabled
```

### 5.7 Selection Model (`10_selection_model.feature`)

```gherkin
Feature: Row Selection Model
  # PDF Section 11

  Scenario: Selection persists across tab change (known behaviour O3)
    Given I have selected 2 rows on "Ready to Push" tab
    When I click the "Pushed" tab
    Then the "N selected" badge should still show "2 selected"
    And the Actions menu should still appear

  Scenario: Selection cleared when rows per page changes
    Given I have selected 3 rows
    When I change rows per page from 10 to 20
    Then the selection should be cleared (badge disappears)
    And I should be on page 1

  Scenario: Selection cleared on successful delete
    Given I have selected 2 rows
    When I delete them successfully
    Then the selection badge should disappear

  Scenario: Selection cleared on company switch
    Given I have selected 1 row
    When I switch to a different company
    Then the selection should be cleared

  Scenario: Selection NOT cleared on page change
    Given I have selected 1 row on page 1
    When I go to page 2
    Then the "N selected" badge should still show "1 selected"
```

### 5.8 Status Badges (`09_status_badges.feature`)

```gherkin
Feature: Status Badges
  # PDF Section 10

  Scenario Outline: Correct status badge for each internal state
    Given a row with internal status "<internal>"
    Then the Status badge should show "<badge>"
    And the Tally Status badge should show "<tally_badge>"

    Examples:
      | internal             | badge                   | tally_badge      |
      | uploaded             | Processing              | Extracting Data  |
      | in_process           | Processing              | Extracting Data  |
      | ready_to_review      | Ready to Review         | Ready to Push    |
      | reviewed             | Reviewed                | Ready to Push    |
      | duplicate            | Duplicate               | Ready to Push    |
      | rejected             | Rejected                | Ready to Push    |
      | duplicate_processing | Duplicate · Extracting  | Ready to Push    |
      | failed               | Failed                  | Failed           |
      | ocr_failed           | Failed                  | N/A              |
```

---

## 6. API Mocking and State Setup Strategy

### The Challenge
Many tests require the app to be in a specific state (e.g., "an invoice is currently
pushing"). Waiting for real processing would make tests slow and flaky.

### Strategy: Hybrid Approach

```
┌────────────────────────────────────────────────────────────┐
│  REAL API (staging/test environment)                       │
│  - Authentication (real login)                             │
│  - Fetching company list                                   │
│  - Upload endpoint (for actual file upload tests)          │
└────────────────────────────────────────────────────────────┘
          ↕ Playwright route() interception
┌────────────────────────────────────────────────────────────┐
│  MOCKED API (for state-dependent tests)                    │
│  - GET /api/invoice/list → return JSON fixture             │
│  - SSE stream → simulate invoice_status events             │
│  - POST /api/invoice/push/{id} → return success or error   │
│  - PATCH /api/invoice/{id}/mark-status → 200 OK            │
└────────────────────────────────────────────────────────────┘
```

### Fixture JSON Files
Create JSON fixtures for common scenarios:
- `fixtures/api/invoice_list_all_states.json` — one row per status
- `fixtures/api/invoice_list_large.json` — 55+ rows (for pagination + push limit tests)
- `fixtures/api/push_success_response.json`
- `fixtures/api/push_tally_error_response.json`

### SSE Simulation
Use `page.route()` to intercept the SSE endpoint and stream custom events:

```typescript
// sse.helper.ts
async function simulateSSEEvent(page: Page, event: InvoiceStatusEvent) {
  // Inject the event into the already-open SSE connection via
  // a Playwright route handler that serves synthetic SSE chunks
}
```

---

## 7. Hooks and Test Lifecycle

```
Before All Suite:
  - Start Playwright browser
  - Log in once, save auth state to file (storageState)

Before Each Scenario:
  - Load saved auth state (no re-login)
  - Navigate to listing page
  - Set up API mocks (if needed for the scenario)
  - Clear sessionStorage keys (ft_search, ft_statusFilter, etc.)
  - Clear tallyPushDontAskAgain from localStorage

After Each Scenario:
  - Take screenshot on failure
  - Save Playwright trace on failure
  - Clean up any uploaded invoices (via direct API DELETE)

After All Suite:
  - Generate HTML report
  - Close browser
```

---

## 8. Tagging Strategy

```gherkin
@smoke        — Fast, critical-path tests (run on every PR)
@regression   — Full suite (run nightly or on release)
@rbac         — All permission-related scenarios
@upload       — All upload dialog scenarios
@push         — All Tally push scenarios
@filters      — All filter/search/sort scenarios
@tabs         — Tab-related scenarios
@pagination   — Pagination scenarios
@realtime     — SSE / polling scenarios (may need longer timeouts)
@known-gap    — Scenarios documenting O1-O11 known bugs (run as xfail)
@skip         — Temporarily disabled
```

Run only smoke tests:
```bash
npx playwright test --grep @smoke
# or with cucumber
cucumber --tags @smoke
```

---

## 9. Known Gaps (O1-O11) — How to Handle

The PDF documents 11 known observations/bugs. These should NOT be silent — they
should be **documented as skipped/xfail scenarios** so they appear in the report
and serve as a backlog.

```gherkin
@known-gap @O2
Scenario: Duplicate rows can be pushed (known gap O2)
  # PDF: "Locked duplicates/rejected can still be pushed"
  Given a row with status "Duplicate" is selected on the "Failed" tab
  When I click "Tally Push"
  Then the push should be BLOCKED (this currently FAILS — the server allows it)
  # This test is tagged @known-gap and is expected to fail until O2 is fixed
```

This approach:
- Makes the gap visible in every report
- When the bug is fixed, the test will PASS, signalling that the gap tag can be removed
- Prevents the team from accidentally re-introducing the gap

---

## 10. RBAC Test Matrix

For each RBAC-protected control, test with:
1. **Owner** — should always see and be able to use it
2. **Sub-user WITH the right** — should see and use it
3. **Sub-user WITHOUT the right** — control should be HIDDEN or show an error

Create a matrix:

| Control | Right needed | Owner | With right | Without right |
|---|---|---|---|---|
| Upload Invoice button | upload_invoice | Visible | Visible | Error toast |
| Tally Push button | push_to_tally | Visible | Visible | Hidden |
| Actions → Transfer | transfer_invoice | Visible | Visible | Hidden in menu |
| Actions → Mark as Duplicate | reject_invoice | Visible | Visible | Hidden in menu |
| Actions → Reject Invoices | reject_invoice | Visible | Visible | Hidden in menu |
| Actions → Delete | delete_invoice | Visible | Visible | Hidden in menu |
| Row trash icon | delete_invoice | Visible | Visible | Hidden |
| Download | (none) | Visible | Visible | Visible |
| Search / Sort / Filters | (none) | Usable | Usable | Usable |

---

## 11. Real-Time Behaviour Tests

These are the hardest to test. Use Playwright's route interception + custom SSE.

### What to test:

1. **SSE invoice_status event → row status updates without page refresh**
   - Intercept SSE, inject `{invoice_id: X, status: "ready_to_review"}` event
   - Verify row badge changes from "Processing" to "Ready to Review"

2. **30-second polling activates only when a row is processing**
   - Mock the list endpoint, verify it is re-called after ~30s only when a
     processing row exists

3. **Stuck-row safety net**
   - Load a page where a row is in_process but has OCR data + auto_tag_status = completed
   - Verify it is immediately shown as "Ready to Review"

4. **Uploading Files panel progress**
   - Upload a file, verify the panel appears with a progress bar
   - Verify "Uploaded successfully" appears and panel disappears after 1s

5. **Pushing to Tally panel**
   - Trigger push, verify panel appears bottom-right
   - Verify each file shows progress
   - Simulate success: panel shows "Synced to Tally" for 3s then disappears
   - Simulate failure: panel shows Tally error for 5s

---

## 12. State Persistence Tests

```gherkin
Feature: State Persistence Between Visits
  # PDF Section 16

  Scenario: Session storage preserves filters when returning from review
    Given I set search = "ACME" and status filter = "Reviewed"
    When I open an invoice for review
    And I return to the listing page (browser back or close review)
    Then the search box should show "ACME"
    And the status filter should still be "Reviewed"

  Scenario: Active company is remembered via localStorage
    Given I switch to "Company B"
    When I refresh the page
    Then "Company B" should still be selected

  Scenario: Sort order is NOT remembered after refresh
    Given I sort by "File Name" ascending
    When I refresh the page
    Then the table should be unsorted (server order)

  Scenario: Current page is NOT remembered after refresh
    Given I navigate to page 3
    When I refresh the page
    Then I should be on page 1
```

---

## 13. CI/CD Integration

### GitHub Actions Workflow (Recommended)

```yaml
# .github/workflows/ui-tests.yml
name: Munshi UI Tests

on:
  push:
    branches: [main, staging]
  pull_request:
  schedule:
    - cron: '0 2 * * *'   # Nightly at 2 AM
  workflow_dispatch:
    inputs:
      tags:
        description: 'Cucumber/Playwright tags to run'
        default: '@regression'

jobs:
  ui-tests:
    runs-on: ubuntu-latest
    strategy:
      matrix:
        browser: [chromium, firefox]   # Add webkit if needed
      fail-fast: false

    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-node@v4
        with:
          node-version: '20'

      - name: Install dependencies
        run: npm ci

      - name: Install Playwright browsers
        run: npx playwright install --with-deps ${{ matrix.browser }}

      - name: Run UI tests
        run: npx playwright test --project=${{ matrix.browser }}
        env:
          BASE_URL: ${{ secrets.STAGING_URL }}
          OWNER_EMAIL: ${{ secrets.OWNER_EMAIL }}
          OWNER_PASSWORD: ${{ secrets.OWNER_PASSWORD }}

      - name: Upload test report
        if: always()
        uses: actions/upload-artifact@v4
        with:
          name: test-report-${{ matrix.browser }}
          path: test-results/

      - name: Upload Playwright traces on failure
        if: failure()
        uses: actions/upload-artifact@v4
        with:
          name: traces-${{ matrix.browser }}
          path: test-results/**/*.zip
```

---

## 14. Reporting

### Recommended Report Stack

1. **Playwright Built-in HTML Report** (`npx playwright show-report`)
   - Shows screenshots, videos, traces per failing test
   - Best for debugging

2. **Cucumber HTML Report** (`@cucumber/html-formatter`)
   - Shows scenarios, steps, tags, pass/fail/skip breakdown
   - Good for stakeholder communication

3. **Allure Report** (optional, for large teams)
   - Trendy pass/fail charts
   - Integrates with Jira

### Report Contents Per Test Run
- Total: passed / failed / skipped / known-gaps
- Per feature file breakdown
- Screenshots of failures
- Playwright trace links (click-through timeline)
- Known gap summary (O1-O11 status)

---

## 15. Phased Rollout Plan

### Phase 1 — Foundation (Week 1-2)
- [ ] Set up project structure (Playwright + playwright-bdd)
- [ ] Implement login / auth state reuse
- [ ] Build ListingPage POM with all locators
- [ ] Write API helper (direct REST calls for seed/teardown)
- [ ] Write 5 smoke scenarios (upload, tab click, push button visibility, search, row click)
- [ ] Set up GitHub Actions pipeline

### Phase 2 — Core Coverage (Week 3-4)
- [ ] All Tally Status Tab scenarios
- [ ] Full Upload dialog scenarios (all 5 voucher types + duplicate + mode toggle)
- [ ] Full Actions menu scenarios (download, transfer, duplicate, reject, delete)
- [ ] Tally Push button (confirm dialog, guard checks, optimistic UI, results)
- [ ] Column sorting scenarios
- [ ] Copy Invoice Details

### Phase 3 — Advanced Coverage (Week 5-6)
- [ ] RBAC matrix (all 6 rights × 3 user types)
- [ ] Date filter (all 4 date types × 6 range chips + custom range)
- [ ] State persistence (session + local storage)
- [ ] Real-time (SSE simulation, polling, stuck-row safety net)
- [ ] Pagination edge cases

### Phase 4 — Known Gaps as Xfail (Week 7)
- [ ] Scenarios for O1-O11 (all marked @known-gap)
- [ ] Ensure they appear in the report clearly

### Phase 5 — Hardening (Week 8)
- [ ] Flaky test elimination (smart waits, retry strategy)
- [ ] Cross-browser matrix (Chromium + Firefox)
- [ ] Performance: ensure full suite runs in < 15 minutes
- [ ] Integrate with Slack/email notifications on failure

---

## 16. Smart Wait Strategy (Critical for Reliability)

The listing page has heavy real-time behaviour (SSE, polling, status transitions).
Naive `waitForTimeout` will cause flakiness.

### Rules:
1. **Never use `waitForTimeout`** except in SSE simulation helpers
2. Use `waitForSelector` / `locator.waitFor()` with `state: 'visible'`
3. For status transitions: poll the row status every 500ms with a 30s timeout
4. For toasts: use `waitForToast(text)` helper that listens for the toast element
5. For file downloads: use `waitForEvent('download')`
6. For API responses: use `waitForResponse` with URL matching

```typescript
// helpers/wait.helper.ts
async function waitForRowStatus(
  page: Page,
  rowName: string,
  expectedStatus: string,
  timeout = 30_000
) {
  await expect(async () => {
    const status = await getRowStatus(page, rowName)
    expect(status).toBe(expectedStatus)
  }).toPass({ timeout })
}
```

---

## 17. Environment Configuration

```typescript
// playwright.config.ts
export default defineConfig({
  testDir: './features',
  timeout: 60_000,
  retries: process.env.CI ? 2 : 0,  // Retry twice in CI
  reporter: [
    ['html', { outputFolder: 'test-results/html' }],
    ['json', { outputFile: 'test-results/results.json' }],
  ],
  use: {
    baseURL: process.env.BASE_URL ?? 'http://localhost:3000',
    storageState: 'auth/owner.json',  // Reuse auth
    screenshot: 'only-on-failure',
    video: 'retain-on-failure',
    trace: 'retain-on-failure',
  },
  projects: [
    { name: 'chromium', use: { ...devices['Desktop Chrome'] } },
    { name: 'firefox',  use: { ...devices['Desktop Firefox'] } },
  ],
})
```

---

## 18. Summary of What the Agent Tests

Based on the PDF, the agent covers:

| # | Area | Scenarios | Notes |
|---|---|---|---|
| 1 | Page anatomy | Layout present | Smoke |
| 2 | Invoice types | 5 type badges | Per voucher type |
| 3 | Header controls | Company, bell, sync, Tally, Upload | 4 controls |
| 4 | Upload Invoice pre-checks | 4 guard checks | Per permission state |
| 5 | Tally Status Tabs | Tab counts, click behaviour, filter reset | 5 tabs |
| 6 | Search | Case-insensitive, resets page | |
| 7 | Date filter | 4 date types x 6 range chips | Client-side only |
| 8 | Actions menu | Download, Transfer, Duplicate, Reject, Delete | Per RBAC right |
| 9 | Tally Push button | Visibility, label, guards, 5-step flow, toasts | Complex |
| 10 | Table columns | All 9 columns, sorting, copy | |
| 11 | Status badges | 8 internal statuses → badge combos | |
| 12 | Selection model | Cleared by / not cleared by | |
| 13 | Pagination | Rows per page, nav, clamping | |
| 14 | Upload dialog | Mode toggle, drop zone, Single/Multi, merge | |
| 15 | Row lifecycle | 6 branches + real-time channels | SSE simulation |
| 16 | RBAC | 6 rights × 3 user types | 18 checks |
| 17 | State persistence | sessionStorage + localStorage | |
| 18 | Known gaps O1-O11 | All 11 gaps | @known-gap, xfail |
| 19 | Official checklist | All 12 items from PDF section 19 | @regression |

**Total estimated scenarios: ~120-150 scenarios**
**Estimated runtime: 12-18 minutes (parallel, Chromium only)**

---

*End of Master Plan*
