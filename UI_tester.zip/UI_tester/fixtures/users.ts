export interface UserRole {
  email: string;
  role: 'owner' | 'accountant' | 'data_entry';
  rights: {
    invoice_listing: boolean;
    upload_invoice: boolean;
    push_to_tally: boolean;
    transfer_invoice: boolean;
    reject_invoice: boolean;
    delete_invoice: boolean;
  };
}

export const USERS: Record<string, UserRole> = {
  owner: {
    email: process.env.OWNER_EMAIL || 'owner@test.com',
    role: 'owner',
    rights: {
      invoice_listing: true,
      upload_invoice: true,
      push_to_tally: true,
      transfer_invoice: true,
      reject_invoice: true,
      delete_invoice: true,
    },
  },
  accountant_with_all: {
    email: process.env.ACCOUNTANT_EMAIL || 'accountant@test.com',
    role: 'accountant',
    rights: {
      invoice_listing: true,
      upload_invoice: true,
      push_to_tally: true,
      transfer_invoice: true,
      reject_invoice: true,
      delete_invoice: true,
    },
  },
  data_entry_restricted: {
    email: process.env.DATA_ENTRY_EMAIL || 'dataentry@test.com',
    role: 'data_entry',
    rights: {
      invoice_listing: true,
      upload_invoice: false,
      push_to_tally: false,
      transfer_invoice: false,
      reject_invoice: false,
      delete_invoice: false,
    },
  },
  subuser_without_transfer: {
    email: 'subuser_notransfer@test.com',
    role: 'accountant',
    rights: {
      invoice_listing: true,
      upload_invoice: true,
      push_to_tally: true,
      transfer_invoice: false,
      reject_invoice: true,
      delete_invoice: true,
    },
  },
  subuser_without_delete: {
    email: 'subuser_nodelete@test.com',
    role: 'data_entry',
    rights: {
      invoice_listing: true,
      upload_invoice: true,
      push_to_tally: true,
      transfer_invoice: true,
      reject_invoice: true,
      delete_invoice: false,
    },
  },
};
