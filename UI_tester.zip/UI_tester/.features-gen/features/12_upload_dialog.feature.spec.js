/** Generated from: features/12_upload_dialog.feature */
import { test } from "../../support/fixtures.ts";

test.describe("Upload Invoice Dialog and Mode Controls", () => {

  test.beforeEach(async ({ Given, mockHelper, storageHelper, And, listingPage, When }) => {
    await Given("I am logged in as the owner", null, { mockHelper, storageHelper });
    await And("I navigate to the Invoice Listing page", null, { listingPage });
    await When("I click the Upload Invoice button in header", null, { listingPage });
  });

  test.describe("Upload invoice with voucher type displays correct badge", () => {

    test("Example #1", { tag: ["@upload", "@regression"] }, async ({ When, listingPage, Then, page }) => {
      await When("I upload \"purchase_invoice.pdf\" as voucher type \"Purchase\"", null, { listingPage });
      await Then("the invoice should appear in the table with type badge \"blue\"", null, { page });
    });

    test("Example #2", { tag: ["@upload", "@regression"] }, async ({ When, listingPage, Then, page }) => {
      await When("I upload \"sales_invoice.pdf\" as voucher type \"Sales\"", null, { listingPage });
      await Then("the invoice should appear in the table with type badge \"green\"", null, { page });
    });

    test("Example #3", { tag: ["@upload", "@regression"] }, async ({ When, listingPage, Then, page }) => {
      await When("I upload \"credit_note.pdf\" as voucher type \"Credit Note\"", null, { listingPage });
      await Then("the invoice should appear in the table with type badge \"amber\"", null, { page });
    });

    test("Example #4", { tag: ["@upload", "@regression"] }, async ({ When, listingPage, Then, page }) => {
      await When("I upload \"debit_note.pdf\" as voucher type \"Debit Note\"", null, { listingPage });
      await Then("the invoice should appear in the table with type badge \"red\"", null, { page });
    });

    test("Example #5", { tag: ["@upload", "@regression"] }, async ({ When, listingPage, Then, page }) => {
      await When("I upload \"expense_invoice.pdf\" as voucher type \"Expense\"", null, { listingPage });
      await Then("the invoice should appear in the table with type badge \"purple\"", null, { page });
    });

  });

  test("Mode switch is locked when files are queued", { tag: ["@upload", "@regression"] }, async ({ Given, listingPage, When, Then }) => {
    await Given("I have selected files in Single mode", null, { listingPage });
    await When("I attempt to switch to Multiple mode", null, { listingPage });
    await Then("the mode switch toggle should be disabled", null, { listingPage });
  });

  test("Upload button is disabled when voucher type is omitted", { tag: ["@upload", "@regression"] }, async ({ Given, listingPage, Then, And }) => {
    await Given("I have queued a file without selecting a voucher type", null, { listingPage });
    await Then("the upload submit button should be disabled", null, { listingPage });
    await And("a validation message \"Please select a voucher type\" should appear", null, { listingPage });
  });

  test("Uploading duplicate invoice triggers duplicate lifecycle and toast", { tag: ["@upload", "@regression"] }, async ({ When, listingPage, Then, And }) => {
    await When("I upload a duplicate invoice file", null, { listingPage });
    await Then("an error toast should mention \"detected as a duplicate invoice\"", null, { listingPage });
    await And("the row status should update to \"Duplicate\"", null, { listingPage });
  });

});

// == technical section ==

test.use({
  $test: ({}, use) => use(test),
  $uri: ({}, use) => use("features/12_upload_dialog.feature"),
  $bddFileMeta: ({}, use) => use(bddFileMeta),
});

const bddFileMeta = {
  "Upload invoice with voucher type displays correct badge|Example #1": {"pickleLocation":"16:7","tags":["@upload","@regression"]},
  "Upload invoice with voucher type displays correct badge|Example #2": {"pickleLocation":"17:7","tags":["@upload","@regression"]},
  "Upload invoice with voucher type displays correct badge|Example #3": {"pickleLocation":"18:7","tags":["@upload","@regression"]},
  "Upload invoice with voucher type displays correct badge|Example #4": {"pickleLocation":"19:7","tags":["@upload","@regression"]},
  "Upload invoice with voucher type displays correct badge|Example #5": {"pickleLocation":"20:7","tags":["@upload","@regression"]},
  "Mode switch is locked when files are queued": {"pickleLocation":"22:3","tags":["@upload","@regression"]},
  "Upload button is disabled when voucher type is omitted": {"pickleLocation":"27:3","tags":["@upload","@regression"]},
  "Uploading duplicate invoice triggers duplicate lifecycle and toast": {"pickleLocation":"32:3","tags":["@upload","@regression"]},
};