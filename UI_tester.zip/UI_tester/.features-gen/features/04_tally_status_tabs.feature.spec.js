/** Generated from: features/04_tally_status_tabs.feature */
import { test } from "../../support/fixtures.ts";

test.describe("Tally Status Tabs", () => {

  test.beforeEach(async ({ Given, mockHelper, storageHelper, And, listingPage }) => {
    await Given("I am logged in as the owner", null, { mockHelper, storageHelper });
    await And("the invoice list is loaded with all status types", null, { mockHelper });
    await And("I navigate to the Invoice Listing page", null, { listingPage });
  });

  test("Tab counts are independent of filters", { tag: ["@tabs", "@regression"] }, async ({ Given, page, When, listingPage, Then, And }) => {
    await Given("the page has 5 \"Ready to Review\" invoices and 3 \"Reviewed\" invoices", null, { page });
    await When("I search for \"Alpha Traders\"", null, { listingPage });
    await Then("the \"Ready to Push\" tab count should remain unchanged", null, { listingPage });
    await And("the \"Failed\" tab count should remain unchanged", null, { listingPage });
  });

  test("All tab hides Tally Push and duplicate/reject action menu items", { tag: ["@tabs", "@regression"] }, async ({ When, listingPage, Then, And }) => {
    await When("I click the \"All\" tab", null, { listingPage });
    await Then("the \"Tally Push\" button should not be visible", null, { listingPage });
    await When("I select 1 invoice", null, { listingPage });
    await And("I open the Actions menu", null, { listingPage });
    await Then("\"Mark as Duplicate\" should not be visible in the menu", null, { listingPage });
    await And("\"Reject Invoices\" should not be visible in the menu", null, { listingPage });
  });

  test("Pushing to Tally tab disables the Tally Push button", { tag: ["@tabs", "@regression"] }, async ({ When, listingPage, Then, And, page }) => {
    await When("I click the \"Pushing to Tally\" tab", null, { listingPage });
    await Then("the \"Tally Push\" button should be visible but disabled", null, { listingPage });
    await And("the tab should show a processing spinner", null, { page });
  });

  test("Pushed tab shows Re Push label", { tag: ["@tabs", "@regression"] }, async ({ When, listingPage, And, Then }) => {
    await When("I click the \"Pushed\" tab", null, { listingPage });
    await And("I select 1 invoice", null, { listingPage });
    await Then("the push button label should be \"Re Push to Tally (1)\"", null, { listingPage });
  });

  test("Failed tab includes duplicate, rejected, and OCR-failed rows", { tag: ["@tabs", "@regression"] }, async ({ When, listingPage, Then, And }) => {
    await When("I click the \"Failed\" tab", null, { listingPage });
    await Then("rows with duplicate, rejected, and ocr_failed should appear", null, { listingPage });
    await And("the tab count should include all three failed status types", null, { listingPage });
  });

  test("Clicking a tab resets page to 1 and clears Tally Status column filter", { tag: ["@tabs", "@regression"] }, async ({ Given, listingPage, When, Then, And, page }) => {
    await Given("I navigate to page 2", null, { listingPage });
    await When("I click the \"Ready to Push\" tab", null, { listingPage });
    await Then("I should be on page 1", null, { listingPage });
    await And("the Tally Status column filter should be reset", null, { page });
  });

});

// == technical section ==

test.use({
  $test: ({}, use) => use(test),
  $uri: ({}, use) => use("features/04_tally_status_tabs.feature"),
  $bddFileMeta: ({}, use) => use(bddFileMeta),
});

const bddFileMeta = {
  "Tab counts are independent of filters": {"pickleLocation":"10:3","tags":["@tabs","@regression"]},
  "All tab hides Tally Push and duplicate/reject action menu items": {"pickleLocation":"16:3","tags":["@tabs","@regression"]},
  "Pushing to Tally tab disables the Tally Push button": {"pickleLocation":"24:3","tags":["@tabs","@regression"]},
  "Pushed tab shows Re Push label": {"pickleLocation":"29:3","tags":["@tabs","@regression"]},
  "Failed tab includes duplicate, rejected, and OCR-failed rows": {"pickleLocation":"34:3","tags":["@tabs","@regression"]},
  "Clicking a tab resets page to 1 and clears Tally Status column filter": {"pickleLocation":"39:3","tags":["@tabs","@regression"]},
};