/** Generated from: features/11_pagination.feature */
import { test } from "../../support/fixtures.ts";

test.describe("Table Pagination and Page Size", () => {

  test.beforeEach(async ({ Given, mockHelper, storageHelper, And, listingPage }) => {
    await Given("I am logged in as the owner", null, { mockHelper, storageHelper });
    await And("the invoice list is loaded with 55 invoices", null, { mockHelper });
    await And("I navigate to the Invoice Listing page", null, { listingPage });
  });

  test("Pagination displays correct summary text", { tag: ["@pagination", "@regression"] }, async ({ Then, listingPage, And }) => {
    await Then("the pagination info should show \"1-10 of 55\"", null, { listingPage });
    await And("the previous page button should be disabled", null, { listingPage });
    await And("the next page button should be enabled", null, { listingPage });
  });

  test("Navigating to next page updates page summary", { tag: ["@pagination", "@regression"] }, async ({ When, listingPage, Then, And }) => {
    await When("I click the next page button", null, { listingPage });
    await Then("the pagination info should show \"11-20 of 55\"", null, { listingPage });
    await And("the previous page button should be enabled", null, { listingPage });
  });

  test("Changing rows per page recalculates page ranges and resets to page 1", { tag: ["@pagination", "@regression"] }, async ({ Given, listingPage, When, Then }) => {
    await Given("I click the next page button", null, { listingPage });
    await When("I change rows per page to 20", null, { listingPage });
    await Then("the pagination info should show \"1-20 of 55\"", null, { listingPage });
  });

});

// == technical section ==

test.use({
  $test: ({}, use) => use(test),
  $uri: ({}, use) => use("features/11_pagination.feature"),
  $bddFileMeta: ({}, use) => use(bddFileMeta),
});

const bddFileMeta = {
  "Pagination displays correct summary text": {"pickleLocation":"10:3","tags":["@pagination","@regression"]},
  "Navigating to next page updates page summary": {"pickleLocation":"15:3","tags":["@pagination","@regression"]},
  "Changing rows per page recalculates page ranges and resets to page 1": {"pickleLocation":"20:3","tags":["@pagination","@regression"]},
};