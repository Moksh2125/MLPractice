/** Generated from: features/03_header_controls.feature */
import { test } from "../../support/fixtures.ts";

test.describe("Header Controls", () => {

  test.beforeEach(async ({ Given, mockHelper, storageHelper, And, listingPage }) => {
    await Given("I am logged in as the owner", null, { mockHelper, storageHelper });
    await And("I navigate to the Invoice Listing page", null, { listingPage });
  });

  test("Switching company clears selection and reloads invoices", { tag: ["@regression"] }, async ({ Given, listingPage, When, storageHelper, Then, And }) => {
    await Given("I select 2 invoices", null, { listingPage });
    await When("I switch to company \"Alpha Enterprises\"", null, { listingPage, storageHelper });
    await Then("the selection should be cleared", null, { listingPage });
    await And("the active company in localStorage should be \"Alpha Enterprises\"", null, { storageHelper });
  });

  test("Locked company displays warning tooltip and cannot be selected", { tag: ["@regression"] }, async ({ When, listingPage, Then, page, And }) => {
    await When("I open the company dropdown", null, { listingPage });
    await Then("a locked company should display a lock icon", null, { page });
    await And("hovering over it should show \"This company is not active under your subscription plan\"", null, { page });
  });

  test("Notification bell shows unread count and caps at 9+", { tag: ["@regression"] }, async ({ When, page, Then, listingPage }) => {
    await When("there are 12 unread notifications", null, { page });
    await Then("the notification bell badge should display \"9+\"", null, { listingPage });
    await When("I click the notification bell", null, { listingPage });
    await Then("the notifications popover should open", null, { page });
  });

  test("Tally Connection popup displays connection status", { tag: ["@regression"] }, async ({ When, listingPage, Then, page, And }) => {
    await When("I click the Tally Connection button", null, { listingPage });
    await Then("the Tally connection popup should appear", null, { page });
    await And("it should display the current status and last sync time", null, { page });
  });

});

// == technical section ==

test.use({
  $test: ({}, use) => use(test),
  $uri: ({}, use) => use("features/03_header_controls.feature"),
  $bddFileMeta: ({}, use) => use(bddFileMeta),
});

const bddFileMeta = {
  "Switching company clears selection and reloads invoices": {"pickleLocation":"9:3","tags":["@regression"]},
  "Locked company displays warning tooltip and cannot be selected": {"pickleLocation":"15:3","tags":["@regression"]},
  "Notification bell shows unread count and caps at 9+": {"pickleLocation":"20:3","tags":["@regression"]},
  "Tally Connection popup displays connection status": {"pickleLocation":"26:3","tags":["@regression"]},
};