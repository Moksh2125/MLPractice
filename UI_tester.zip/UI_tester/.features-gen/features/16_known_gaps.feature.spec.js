/** Generated from: features/16_known_gaps.feature */
import { test } from "../../support/fixtures.ts";

test.describe("Known Product Gaps (O1-O11) Tracking", () => {

  test.beforeEach(async ({ Given, mockHelper, storageHelper, And, listingPage }) => {
    await Given("I am logged in as the owner", null, { mockHelper, storageHelper });
    await And("the invoice list is loaded with all status types", null, { mockHelper });
    await And("I navigate to the Invoice Listing page", null, { listingPage });
  });

  test("Duplicate rows push block verification (Known Gap O2)", { tag: ["@known-gap", "@O2"] }, async ({ Given, listingPage, When, Then }) => {
    await Given("a row with status \"Duplicate\" is selected on the \"Failed\" tab", null, { listingPage });
    await When("I click the Tally Push button", null, { listingPage });
    await Then("pushing duplicate rows should be blocked by the application", null, { listingPage });
  });

  test("Selection persistence across tab change (Known Behavior O3)", { tag: ["@known-gap", "@O3"] }, async ({ Given, listingPage, When, Then }) => {
    await Given("I select 2 invoices on the \"Ready to Push\" tab", null, { listingPage });
    await When("I click the \"Pushed\" tab", null, { listingPage });
    await Then("the selected badge should still show \"2 selected\"", null, { listingPage });
  });

  test("Multi-page selection with 50-limit guard (Known Behavior O7)", { tag: ["@known-gap", "@O7"] }, async ({ Given, page, listingPage, When, Then }) => {
    await Given("I have selected 51 invoices", null, { page, listingPage });
    await When("I click the Tally Push button", null, { listingPage });
    await Then("an error toast should appear with \"Select between 1 and 50 files to push to Tally\"", null, { listingPage });
  });

});

// == technical section ==

test.use({
  $test: ({}, use) => use(test),
  $uri: ({}, use) => use("features/16_known_gaps.feature"),
  $bddFileMeta: ({}, use) => use(bddFileMeta),
});

const bddFileMeta = {
  "Duplicate rows push block verification (Known Gap O2)": {"pickleLocation":"11:3","tags":["@known-gap","@O2"],"ownTags":["@O2"]},
  "Selection persistence across tab change (Known Behavior O3)": {"pickleLocation":"18:3","tags":["@known-gap","@O3"],"ownTags":["@O3"]},
  "Multi-page selection with 50-limit guard (Known Behavior O7)": {"pickleLocation":"24:3","tags":["@known-gap","@O7"],"ownTags":["@O7"]},
};