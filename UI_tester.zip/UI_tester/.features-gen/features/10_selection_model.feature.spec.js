/** Generated from: features/10_selection_model.feature */
import { test } from "../../support/fixtures.ts";

test.describe("Row Selection Model and Persistence", () => {

  test.beforeEach(async ({ Given, mockHelper, storageHelper, And, listingPage }) => {
    await Given("I am logged in as the owner", null, { mockHelper, storageHelper });
    await And("the invoice list is loaded with all status types", null, { mockHelper });
    await And("I navigate to the Invoice Listing page", null, { listingPage });
  });

  test("Row selection persists across tab switches", { tag: ["@regression"] }, async ({ Given, listingPage, When, Then }) => {
    await Given("I select 2 invoices", null, { listingPage });
    await When("I click the \"Pushed\" tab", null, { listingPage });
    await Then("the selected badge should still show \"2 selected\"", null, { listingPage });
  });

  test("Selection is maintained across pagination navigation", { tag: ["@regression"] }, async ({ Given, listingPage, When, Then }) => {
    await Given("I select 1 invoice", null, { listingPage });
    await When("I go to the next page", null, { listingPage });
    await Then("the selected badge should still show \"1 selected\"", null, { listingPage });
  });

  test("Changing rows per page resets selection", { tag: ["@regression"] }, async ({ Given, listingPage, When, Then }) => {
    await Given("I select 2 invoices", null, { listingPage });
    await When("I change rows per page to 20", null, { listingPage });
    await Then("the selection count badge should disappear", null, { listingPage });
  });

  test("Switching company clears selection", { tag: ["@regression"] }, async ({ Given, listingPage, When, storageHelper, Then }) => {
    await Given("I select 1 invoice", null, { listingPage });
    await When("I switch to company \"Alpha Enterprises\"", null, { listingPage, storageHelper });
    await Then("the selection count badge should disappear", null, { listingPage });
  });

});

// == technical section ==

test.use({
  $test: ({}, use) => use(test),
  $uri: ({}, use) => use("features/10_selection_model.feature"),
  $bddFileMeta: ({}, use) => use(bddFileMeta),
});

const bddFileMeta = {
  "Row selection persists across tab switches": {"pickleLocation":"10:3","tags":["@regression"]},
  "Selection is maintained across pagination navigation": {"pickleLocation":"15:3","tags":["@regression"]},
  "Changing rows per page resets selection": {"pickleLocation":"20:3","tags":["@regression"]},
  "Switching company clears selection": {"pickleLocation":"25:3","tags":["@regression"]},
};