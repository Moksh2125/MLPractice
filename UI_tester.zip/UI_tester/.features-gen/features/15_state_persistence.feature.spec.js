/** Generated from: features/15_state_persistence.feature */
import { test } from "../../support/fixtures.ts";

test.describe("State Persistence and Session Storage", () => {

  test.beforeEach(async ({ Given, mockHelper, storageHelper, And, listingPage }) => {
    await Given("I am logged in as the owner", null, { mockHelper, storageHelper });
    await And("the invoice list is loaded with all status types", null, { mockHelper });
    await And("I navigate to the Invoice Listing page", null, { listingPage });
  });

  test("Search query is preserved across review screen navigation", { tag: ["@regression"] }, async ({ Given, listingPage, When, page, storageHelper, Then }) => {
    await Given("I type \"Alpha\" in the search box", null, { listingPage });
    await When("I simulate navigating to review screen and returning", null, { page, storageHelper });
    await Then("the search box should retain value \"Alpha\"", null, { listingPage, storageHelper });
  });

  test("Active company persists in local storage across page reloads", { tag: ["@regression"] }, async ({ Given, listingPage, storageHelper, When, page, Then }) => {
    await Given("I switch to company \"Alpha Enterprises\"", null, { listingPage, storageHelper });
    await When("I reload the page", null, { page });
    await Then("company \"Alpha Enterprises\" should still be selected", null, { storageHelper });
  });

  test("Column sort order resets to default on page refresh", { tag: ["@regression"] }, async ({ Given, listingPage, When, page, Then }) => {
    await Given("I click the \"File Name\" column header once", null, { listingPage });
    await When("I reload the page", null, { page });
    await Then("the table column sort order should reset to default", null, { page });
  });

});

// == technical section ==

test.use({
  $test: ({}, use) => use(test),
  $uri: ({}, use) => use("features/15_state_persistence.feature"),
  $bddFileMeta: ({}, use) => use(bddFileMeta),
});

const bddFileMeta = {
  "Search query is preserved across review screen navigation": {"pickleLocation":"10:3","tags":["@regression"]},
  "Active company persists in local storage across page reloads": {"pickleLocation":"15:3","tags":["@regression"]},
  "Column sort order resets to default on page refresh": {"pickleLocation":"20:3","tags":["@regression"]},
};