/** Generated from: features/08_table_columns.feature */
import { test } from "../../support/fixtures.ts";

test.describe("Table Columns Sorting and Row Interactions", () => {

  test.beforeEach(async ({ Given, mockHelper, storageHelper, And, listingPage }) => {
    await Given("I am logged in as the owner", null, { mockHelper, storageHelper });
    await And("the invoice list is loaded with all status types", null, { mockHelper });
    await And("I navigate to the Invoice Listing page", null, { listingPage });
  });

  test("Sorting columns cycles through directions", { tag: ["@regression"] }, async ({ When, listingPage, Then }) => {
    await When("I click the \"File Name\" column header once", null, { listingPage });
    await Then("the rows should be sorted descending", null, { listingPage });
    await When("I click the \"File Name\" column header again", null, { listingPage });
    await Then("the rows should be sorted ascending", null, { listingPage });
    await When("I click the \"File Name\" column header a third time", null, { listingPage });
    await Then("the sort order should be reset to server order", null, { listingPage });
  });

  test("Invoices sort numerically by invoice number", { tag: ["@regression"] }, async ({ When, listingPage, Then }) => {
    await When("I sort by \"Invoice No\"", null, { listingPage });
    await Then("the invoice numbers should be sorted in numerical order", null, { listingPage });
  });

  test("Copy details icon copies invoice info without opening review screen", { tag: ["@regression"] }, async ({ When, listingPage, Then, page, And }) => {
    await When("I click the copy clipboard icon on invoice \"purchase_sample_01.pdf\"", null, { listingPage });
    await Then("the clipboard should contain invoice metadata", null, { page });
    await And("the copy icon should display a checkmark", null, { page });
    await And("the review page should not open", null, { page });
  });

  test("Processing rows are non-interactive", { tag: ["@regression"] }, async ({ When, listingPage, Then, And, page }) => {
    await When("a row has \"Processing\" status", null, { listingPage });
    await Then("its row checkbox should be disabled", null, { listingPage });
    await And("clicking the row should not navigate to review", null, { listingPage, page });
    await And("its delete trash icon should be disabled", null, { listingPage });
  });

});

// == technical section ==

test.use({
  $test: ({}, use) => use(test),
  $uri: ({}, use) => use("features/08_table_columns.feature"),
  $bddFileMeta: ({}, use) => use(bddFileMeta),
});

const bddFileMeta = {
  "Sorting columns cycles through directions": {"pickleLocation":"10:3","tags":["@regression"]},
  "Invoices sort numerically by invoice number": {"pickleLocation":"18:3","tags":["@regression"]},
  "Copy details icon copies invoice info without opening review screen": {"pickleLocation":"22:3","tags":["@regression"]},
  "Processing rows are non-interactive": {"pickleLocation":"28:3","tags":["@regression"]},
};