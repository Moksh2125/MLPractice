/** Generated from: features/07_tally_push_button.feature */
import { test } from "../../support/fixtures.ts";

test.describe("Tally Push Button and Execution Flow", () => {

  test.beforeEach(async ({ Given, mockHelper, storageHelper, And, listingPage }) => {
    await Given("I am logged in as the owner", null, { mockHelper, storageHelper });
    await And("the invoice list is loaded with all status types", null, { mockHelper });
    await And("I navigate to the Invoice Listing page", null, { listingPage });
  });

  test("Attempting to push more than 50 invoices shows guard error toast", { tag: ["@push", "@regression"] }, async ({ Given, page, listingPage, When, Then }) => {
    await Given("I have selected 51 invoices", null, { page, listingPage });
    await When("I click the Tally Push button", null, { listingPage });
    await Then("an error toast should appear with \"Select between 1 and 50 files to push to Tally\"", null, { listingPage });
  });

  test("Tally push with confirmation dialog", { tag: ["@push", "@regression"] }, async ({ Given, storageHelper, And, listingPage, When, Then }) => {
    await Given("\"tallyPushDontAskAgain\" is not stored in localStorage", null, { storageHelper });
    await And("I select 2 invoices", null, { listingPage });
    await When("I click the Tally Push button", null, { listingPage });
    await Then("the push confirmation dialog should appear", null, { listingPage });
    await When("I click \"Push anyway\" in confirmation dialog", null, { listingPage });
    await Then("the \"Pushing to Tally\" panel should appear at bottom right", null, { listingPage });
    await And("the selected rows should transition to \"Pushing\" status", null, { listingPage });
  });

  test("Tally push skips dialog when Don't ask again is set", { tag: ["@push", "@regression"] }, async ({ Given, storageHelper, And, listingPage, When, Then }) => {
    await Given("\"tallyPushDontAskAgain\" is set to \"true\" in localStorage", null, { storageHelper });
    await And("I select 1 invoice", null, { listingPage });
    await When("I click the Tally Push button", null, { listingPage });
    await Then("the push confirmation dialog should not appear", null, { listingPage });
    await And("the push should proceed directly", null, { listingPage });
  });

  test("Successful push updates rows to Reviewed and Pushed", { tag: ["@push", "@regression"] }, async ({ Given, listingPage, And, mockHelper, When, Then }) => {
    await Given("I select 2 invoices", null, { listingPage });
    await And("the push API will succeed", null, { mockHelper });
    await When("I trigger push execution", null, { listingPage });
    await Then("the rows should update to status \"Reviewed\"", null, { listingPage });
    await And("the rows should have Tally status \"Pushed\"", null, { listingPage });
    await And("the floating push panel should show \"Synced to Tally\"", null, { listingPage });
  });

  test("Failed push updates rows to Failed and records errors", { tag: ["@push", "@regression"] }, async ({ Given, listingPage, And, mockHelper, When, Then }) => {
    await Given("I select 2 invoices", null, { listingPage });
    await And("the push API will fail with Tally errors", null, { mockHelper });
    await When("I trigger push execution", null, { listingPage });
    await Then("the rows should update to Tally status \"Failed\"", null, { listingPage });
    await And("the Tally error should appear in the notification center", null, { listingPage });
  });

});

// == technical section ==

test.use({
  $test: ({}, use) => use(test),
  $uri: ({}, use) => use("features/07_tally_push_button.feature"),
  $bddFileMeta: ({}, use) => use(bddFileMeta),
});

const bddFileMeta = {
  "Attempting to push more than 50 invoices shows guard error toast": {"pickleLocation":"10:3","tags":["@push","@regression"]},
  "Tally push with confirmation dialog": {"pickleLocation":"15:3","tags":["@push","@regression"]},
  "Tally push skips dialog when Don't ask again is set": {"pickleLocation":"24:3","tags":["@push","@regression"]},
  "Successful push updates rows to Reviewed and Pushed": {"pickleLocation":"31:3","tags":["@push","@regression"]},
  "Failed push updates rows to Failed and records errors": {"pickleLocation":"39:3","tags":["@push","@regression"]},
};