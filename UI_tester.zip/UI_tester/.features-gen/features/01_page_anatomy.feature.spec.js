/** Generated from: features/01_page_anatomy.feature */
import { test } from "../../support/fixtures.ts";

test.describe("Page Anatomy and Layout", () => {

  test.beforeEach(async ({ Given, mockHelper, storageHelper, And, listingPage }) => {
    await Given("I am logged in as the owner", null, { mockHelper, storageHelper });
    await And("I navigate to the Invoice Listing page", null, { listingPage });
  });

  test("All core UI sections are visible", { tag: ["@smoke", "@regression"] }, async ({ Then, page, And, listingPage }) => {
    await Then("the sidebar should be visible", null, { page });
    await And("the header with company dropdown, notification bell, and upload button should be visible", null, { listingPage });
    await And("the Tally status tabs \"All, Ready to Push, Pushing to Tally, Pushed, Failed\" should be visible", null, { page });
    await And("the filter bar with search box and date filter should be visible", null, { listingPage });
    await And("the invoice table headers should be visible", null, { page });
    await And("the pagination controls should be visible", null, { listingPage });
  });

});

// == technical section ==

test.use({
  $test: ({}, use) => use(test),
  $uri: ({}, use) => use("features/01_page_anatomy.feature"),
  $bddFileMeta: ({}, use) => use(bddFileMeta),
});

const bddFileMeta = {
  "All core UI sections are visible": {"pickleLocation":"9:3","tags":["@smoke","@regression"]},
};