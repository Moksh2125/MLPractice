/** Generated from: features/05_filter_bar.feature */
import { test } from "../../support/fixtures.ts";

test.describe("Filter Bar — Search and Date Filter", () => {

  test.beforeEach(async ({ Given, mockHelper, storageHelper, And, listingPage }) => {
    await Given("I am logged in as the owner", null, { mockHelper, storageHelper });
    await And("the invoice list is loaded with all status types", null, { mockHelper });
    await And("I navigate to the Invoice Listing page", null, { listingPage });
  });

  test("Search is case-insensitive and resets pagination to page 1", { tag: ["@filters", "@regression"] }, async ({ Given, listingPage, When, Then, And }) => {
    await Given("I navigate to page 2", null, { listingPage });
    await When("I type \"ALPHA\" in the search box", null, { listingPage });
    await Then("only rows containing \"alpha\" case-insensitively should be shown", null, { listingPage });
    await And("I should be on page 1", null, { listingPage });
  });

  test("Date filter is completely client-side without API calls", { tag: ["@filters", "@regression"] }, async ({ Given, page, When, listingPage, Then }) => {
    await Given("the network is monitored for \"/api/invoice/list\"", null, { page });
    await When("I select date range \"Last 7 Days\"", null, { listingPage });
    await Then("no network request should be made to \"/api/invoice/list\"", null, { page });
  });

  test("Custom date range clears To date if From is set after To", { tag: ["@filters", "@regression"] }, async ({ When, listingPage, And, Then }) => {
    await When("I open the date filter and choose \"Custom Range\"", null, { listingPage });
    await And("I set the \"From\" date to \"2026-11-15\"", null, { listingPage });
    await And("I set the \"To\" date to \"2026-11-01\"", null, { listingPage });
    await Then("the \"To\" date field should be automatically cleared", null, { listingPage });
  });

  test("Filters combine cumulatively with tab and search", { tag: ["@filters", "@regression"] }, async ({ Given, listingPage, When, And, Then }) => {
    await Given("I click the \"Ready to Push\" tab", null, { listingPage });
    await When("I type \"Alpha\" in the search box", null, { listingPage });
    await And("I select date range \"This Month\"", null, { listingPage });
    await Then("the table should only show rows matching the tab, search, and date range", null, { listingPage });
  });

});

// == technical section ==

test.use({
  $test: ({}, use) => use(test),
  $uri: ({}, use) => use("features/05_filter_bar.feature"),
  $bddFileMeta: ({}, use) => use(bddFileMeta),
});

const bddFileMeta = {
  "Search is case-insensitive and resets pagination to page 1": {"pickleLocation":"10:3","tags":["@filters","@regression"]},
  "Date filter is completely client-side without API calls": {"pickleLocation":"16:3","tags":["@filters","@regression"]},
  "Custom date range clears To date if From is set after To": {"pickleLocation":"21:3","tags":["@filters","@regression"]},
  "Filters combine cumulatively with tab and search": {"pickleLocation":"27:3","tags":["@filters","@regression"]},
};