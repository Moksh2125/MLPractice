/** Generated from: features/14_rbac_permissions.feature */
import { test } from "../../support/fixtures.ts";

test.describe("Role-Based Access Control (RBAC) Permissions", () => {

  test("User without push_to_tally right does not see push button", { tag: ["@rbac", "@regression"] }, async ({ Given, storageHelper, And, listingPage, Then }) => {
    await Given("I am logged in as a sub-user without \"push_to_tally\" permission", null, { storageHelper });
    await And("I navigate to the Invoice Listing page", null, { listingPage });
    await Then("the \"Tally Push\" button should not be visible", null, { listingPage });
  });

  test("User without upload_invoice right receives warning on upload attempt", { tag: ["@rbac", "@regression"] }, async ({ Given, storageHelper, And, listingPage, When, Then }) => {
    await Given("I am logged in as a sub-user without \"upload_invoice\" permission", null, { storageHelper });
    await And("I navigate to the Invoice Listing page", null, { listingPage });
    await When("I click the Upload Invoice button in header", null, { listingPage });
    await Then("an error toast should indicate missing upload permission", null, { listingPage });
  });

  test("User without transfer_invoice cannot see Transfer action", { tag: ["@rbac", "@regression"] }, async ({ Given, storageHelper, And, listingPage, When, Then }) => {
    await Given("I am logged in as a sub-user without \"transfer_invoice\" permission", null, { storageHelper });
    await And("I navigate to the Invoice Listing page", null, { listingPage });
    await When("I select 1 invoice", null, { listingPage });
    await And("I open the Actions menu", null, { listingPage });
    await Then("\"Transfer\" should not be visible in the menu", null, { listingPage });
  });

  test("User without delete_invoice right cannot delete rows", { tag: ["@rbac", "@regression"] }, async ({ Given, storageHelper, And, listingPage, When, Then }) => {
    await Given("I am logged in as a sub-user without \"delete_invoice\" permission", null, { storageHelper });
    await And("I navigate to the Invoice Listing page", null, { listingPage });
    await When("I select 1 invoice", null, { listingPage });
    await And("I open the Actions menu", null, { listingPage });
    await Then("\"Delete\" should not be visible in the menu", null, { listingPage });
    await And("row delete trash icons should not be present in the table", null, { listingPage });
  });

});

// == technical section ==

test.use({
  $test: ({}, use) => use(test),
  $uri: ({}, use) => use("features/14_rbac_permissions.feature"),
  $bddFileMeta: ({}, use) => use(bddFileMeta),
});

const bddFileMeta = {
  "User without push_to_tally right does not see push button": {"pickleLocation":"5:3","tags":["@rbac","@regression"]},
  "User without upload_invoice right receives warning on upload attempt": {"pickleLocation":"10:3","tags":["@rbac","@regression"]},
  "User without transfer_invoice cannot see Transfer action": {"pickleLocation":"16:3","tags":["@rbac","@regression"]},
  "User without delete_invoice right cannot delete rows": {"pickleLocation":"23:3","tags":["@rbac","@regression"]},
};