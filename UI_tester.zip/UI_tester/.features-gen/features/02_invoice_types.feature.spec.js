/** Generated from: features/02_invoice_types.feature */
import { test } from "../../support/fixtures.ts";

test.describe("Invoice Types and Mode Badges", () => {

  test.beforeEach(async ({ Given, mockHelper, storageHelper, And }) => {
    await Given("I am logged in as the owner", null, { mockHelper, storageHelper });
    await And("the invoice list is loaded with all status types", null, { mockHelper });
  });

  test.describe("Invoice type displays with correct visual badge", () => {

    test("Example #1", { tag: ["@regression"] }, async ({ When, listingPage, Then, page }) => {
      await When("I look at an invoice with type \"Purchase\"", null, { listingPage });
      await Then("the invoice type badge should be \"blue\"", null, { page });
    });

    test("Example #2", { tag: ["@regression"] }, async ({ When, listingPage, Then, page }) => {
      await When("I look at an invoice with type \"Sales\"", null, { listingPage });
      await Then("the invoice type badge should be \"green\"", null, { page });
    });

    test("Example #3", { tag: ["@regression"] }, async ({ When, listingPage, Then, page }) => {
      await When("I look at an invoice with type \"Credit Note\"", null, { listingPage });
      await Then("the invoice type badge should be \"amber\"", null, { page });
    });

    test("Example #4", { tag: ["@regression"] }, async ({ When, listingPage, Then, page }) => {
      await When("I look at an invoice with type \"Debit Note\"", null, { listingPage });
      await Then("the invoice type badge should be \"red\"", null, { page });
    });

    test("Example #5", { tag: ["@regression"] }, async ({ When, listingPage, Then, page }) => {
      await When("I look at an invoice with type \"Expense\"", null, { listingPage });
      await Then("the invoice type badge should be \"purple\"", null, { page });
    });

  });

  test("Expense vouchers are treated as journal type vouchers", { tag: ["@regression"] }, async ({ When, listingPage, Then, page }) => {
    await When("an invoice is of type \"Expense\"", null, { listingPage });
    await Then("it should retain its expense voucher mode regardless of inventory settings", null, { page });
  });

});

// == technical section ==

test.use({
  $test: ({}, use) => use(test),
  $uri: ({}, use) => use("features/02_invoice_types.feature"),
  $bddFileMeta: ({}, use) => use(bddFileMeta),
});

const bddFileMeta = {
  "Invoice type displays with correct visual badge|Example #1": {"pickleLocation":"15:7","tags":["@regression"]},
  "Invoice type displays with correct visual badge|Example #2": {"pickleLocation":"16:7","tags":["@regression"]},
  "Invoice type displays with correct visual badge|Example #3": {"pickleLocation":"17:7","tags":["@regression"]},
  "Invoice type displays with correct visual badge|Example #4": {"pickleLocation":"18:7","tags":["@regression"]},
  "Invoice type displays with correct visual badge|Example #5": {"pickleLocation":"19:7","tags":["@regression"]},
  "Expense vouchers are treated as journal type vouchers": {"pickleLocation":"21:3","tags":["@regression"]},
};