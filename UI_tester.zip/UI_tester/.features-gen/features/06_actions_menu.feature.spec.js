/** Generated from: features/06_actions_menu.feature */
import { test } from "../../support/fixtures.ts";

test.describe("Actions Menu Bulk Operations", () => {

  test.beforeEach(async ({ Given, mockHelper, storageHelper, And, listingPage }) => {
    await Given("I am logged in as the owner", null, { mockHelper, storageHelper });
    await And("the invoice list is loaded with all status types", null, { mockHelper });
    await And("I navigate to the Invoice Listing page", null, { listingPage });
  });

  test("Actions menu is hidden when no rows are selected", { tag: ["@regression"] }, async ({ When, listingPage, Then }) => {
    await When("no rows are selected", null, { listingPage });
    await Then("the Actions menu should not be visible", null, { listingPage });
  });

  test("Actions menu appears when at least one row is selected", { tag: ["@regression"] }, async ({ When, listingPage, Then }) => {
    await When("I select 1 invoice", null, { listingPage });
    await Then("the Actions menu should be visible", null, { listingPage });
  });

  test("Download single invoice starts direct file download", { tag: ["@regression"] }, async ({ Given, listingPage, When, Then, page, And }) => {
    await Given("I select 1 invoice", null, { listingPage });
    await When("I click Actions download", null, { listingPage });
    await Then("a file download should trigger", null, { page });
    await And("a toast message \"Invoice downloaded successfully\" should appear", null, { listingPage });
  });

  test("Download multiple invoices triggers ZIP download", { tag: ["@regression"] }, async ({ Given, listingPage, When, Then, page, And }) => {
    await Given("I select 2 invoices", null, { listingPage });
    await When("I click Actions download", null, { listingPage });
    await Then("a ZIP file download should trigger", null, { page });
    await And("a toast message \"invoices downloaded as ZIP\" should appear", null, { listingPage });
  });

  test("Mark as Duplicate updates row status and shows toast", { tag: ["@regression"] }, async ({ Given, listingPage, And, When, mockHelper, Then }) => {
    await Given("I click the \"Ready to Push\" tab", null, { listingPage });
    await And("I select 1 invoice", null, { listingPage });
    await When("I select \"Mark as Duplicate\" from Actions menu", null, { listingPage, mockHelper });
    await And("I confirm the modal", null, { listingPage });
    await Then("the row status should update to \"Duplicate\"", null, { listingPage });
    await And("a toast message \"marked as duplicate\" should appear", null, { listingPage });
  });

  test("Delete invoices removes rows and clears selection", { tag: ["@regression"] }, async ({ Given, listingPage, When, mockHelper, And, Then }) => {
    await Given("I select 2 invoices", null, { listingPage });
    await When("I select \"Delete\" from Actions menu", null, { listingPage, mockHelper });
    await And("I confirm the modal", null, { listingPage });
    await Then("the selected rows should be removed from the table", null, { listingPage });
    await And("the selection count badge should disappear", null, { listingPage });
    await And("a toast message \"deleted successfully\" should appear", null, { listingPage });
  });

});

// == technical section ==

test.use({
  $test: ({}, use) => use(test),
  $uri: ({}, use) => use("features/06_actions_menu.feature"),
  $bddFileMeta: ({}, use) => use(bddFileMeta),
});

const bddFileMeta = {
  "Actions menu is hidden when no rows are selected": {"pickleLocation":"10:3","tags":["@regression"]},
  "Actions menu appears when at least one row is selected": {"pickleLocation":"14:3","tags":["@regression"]},
  "Download single invoice starts direct file download": {"pickleLocation":"18:3","tags":["@regression"]},
  "Download multiple invoices triggers ZIP download": {"pickleLocation":"24:3","tags":["@regression"]},
  "Mark as Duplicate updates row status and shows toast": {"pickleLocation":"30:3","tags":["@regression"]},
  "Delete invoices removes rows and clears selection": {"pickleLocation":"38:3","tags":["@regression"]},
};