/** Generated from: features/09_status_badges.feature */
import { test } from "../../support/fixtures.ts";

test.describe("Status Badge Matrix", () => {

  test.beforeEach(async ({ Given, mockHelper, storageHelper, And, listingPage }) => {
    await Given("I am logged in as the owner", null, { mockHelper, storageHelper });
    await And("the invoice list is loaded with all status types", null, { mockHelper });
    await And("I navigate to the Invoice Listing page", null, { listingPage });
  });

  test.describe("Internal invoice status maps to correct UI badges", () => {

    test("Example #1", { tag: ["@regression"] }, async ({ When, page, Then, listingPage, And }) => {
      await When("an invoice has internal state \"uploaded\"", null, { page });
      await Then("the Status column badge should show \"Processing\"", null, { listingPage });
      await And("the Tally Status column badge should show \"Extracting Data\"", null, { listingPage });
    });

    test("Example #2", { tag: ["@regression"] }, async ({ When, page, Then, listingPage, And }) => {
      await When("an invoice has internal state \"in_process\"", null, { page });
      await Then("the Status column badge should show \"Processing\"", null, { listingPage });
      await And("the Tally Status column badge should show \"Extracting Data\"", null, { listingPage });
    });

    test("Example #3", { tag: ["@regression"] }, async ({ When, page, Then, listingPage, And }) => {
      await When("an invoice has internal state \"ready_to_review\"", null, { page });
      await Then("the Status column badge should show \"Ready to Review\"", null, { listingPage });
      await And("the Tally Status column badge should show \"Ready to Push\"", null, { listingPage });
    });

    test("Example #4", { tag: ["@regression"] }, async ({ When, page, Then, listingPage, And }) => {
      await When("an invoice has internal state \"reviewed\"", null, { page });
      await Then("the Status column badge should show \"Reviewed\"", null, { listingPage });
      await And("the Tally Status column badge should show \"Ready to Push\"", null, { listingPage });
    });

    test("Example #5", { tag: ["@regression"] }, async ({ When, page, Then, listingPage, And }) => {
      await When("an invoice has internal state \"duplicate\"", null, { page });
      await Then("the Status column badge should show \"Duplicate\"", null, { listingPage });
      await And("the Tally Status column badge should show \"Ready to Push\"", null, { listingPage });
    });

    test("Example #6", { tag: ["@regression"] }, async ({ When, page, Then, listingPage, And }) => {
      await When("an invoice has internal state \"rejected\"", null, { page });
      await Then("the Status column badge should show \"Rejected\"", null, { listingPage });
      await And("the Tally Status column badge should show \"Ready to Push\"", null, { listingPage });
    });

    test("Example #7", { tag: ["@regression"] }, async ({ When, page, Then, listingPage, And }) => {
      await When("an invoice has internal state \"duplicate_processing\"", null, { page });
      await Then("the Status column badge should show \"Duplicate · Extracting\"", null, { listingPage });
      await And("the Tally Status column badge should show \"Ready to Push\"", null, { listingPage });
    });

    test("Example #8", { tag: ["@regression"] }, async ({ When, page, Then, listingPage, And }) => {
      await When("an invoice has internal state \"failed\"", null, { page });
      await Then("the Status column badge should show \"Failed\"", null, { listingPage });
      await And("the Tally Status column badge should show \"Failed\"", null, { listingPage });
    });

    test("Example #9", { tag: ["@regression"] }, async ({ When, page, Then, listingPage, And }) => {
      await When("an invoice has internal state \"ocr_failed\"", null, { page });
      await Then("the Status column badge should show \"Failed\"", null, { listingPage });
      await And("the Tally Status column badge should show \"N/A\"", null, { listingPage });
    });

  });

});

// == technical section ==

test.use({
  $test: ({}, use) => use(test),
  $uri: ({}, use) => use("features/09_status_badges.feature"),
  $bddFileMeta: ({}, use) => use(bddFileMeta),
});

const bddFileMeta = {
  "Internal invoice status maps to correct UI badges|Example #1": {"pickleLocation":"17:7","tags":["@regression"]},
  "Internal invoice status maps to correct UI badges|Example #2": {"pickleLocation":"18:7","tags":["@regression"]},
  "Internal invoice status maps to correct UI badges|Example #3": {"pickleLocation":"19:7","tags":["@regression"]},
  "Internal invoice status maps to correct UI badges|Example #4": {"pickleLocation":"20:7","tags":["@regression"]},
  "Internal invoice status maps to correct UI badges|Example #5": {"pickleLocation":"21:7","tags":["@regression"]},
  "Internal invoice status maps to correct UI badges|Example #6": {"pickleLocation":"22:7","tags":["@regression"]},
  "Internal invoice status maps to correct UI badges|Example #7": {"pickleLocation":"23:7","tags":["@regression"]},
  "Internal invoice status maps to correct UI badges|Example #8": {"pickleLocation":"24:7","tags":["@regression"]},
  "Internal invoice status maps to correct UI badges|Example #9": {"pickleLocation":"25:7","tags":["@regression"]},
};