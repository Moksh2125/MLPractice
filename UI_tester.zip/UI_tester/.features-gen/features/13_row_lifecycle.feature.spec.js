/** Generated from: features/13_row_lifecycle.feature */
import { test } from "../../support/fixtures.ts";

test.describe("Invoice Row Lifecycle and Real-Time SSE", () => {

  test.beforeEach(async ({ Given, mockHelper, storageHelper, And, listingPage }) => {
    await Given("I am logged in as the owner", null, { mockHelper, storageHelper });
    await And("the invoice list is loaded with all status types", null, { mockHelper });
    await And("I navigate to the Invoice Listing page", null, { listingPage });
  });

  test("Row transitions status in real-time via SSE event", { tag: ["@realtime", "@regression"] }, async ({ Given, listingPage, When, sseHelper, Then, waitHelper }) => {
    await Given("row \"processing_sample_09.pdf\" is in status \"Processing\"", null, { listingPage });
    await When("an SSE status event arrives with status \"ready_to_review\" for \"processing_sample_09.pdf\"", null, { sseHelper });
    await Then("the row status badge should update to \"Ready to Review\" without page refresh", null, { listingPage, waitHelper });
  });

  test("Stuck row with completed OCR renders as Ready to Review", { tag: ["@realtime", "@regression"] }, async ({ Given, mockHelper, When, listingPage, Then }) => {
    await Given("an invoice has in_process backend flag but completed OCR data", null, { mockHelper });
    await When("the invoice table is rendered", null, { listingPage });
    await Then("the row status should be displayed as \"Ready to Review\"", null, { listingPage });
  });

});

// == technical section ==

test.use({
  $test: ({}, use) => use(test),
  $uri: ({}, use) => use("features/13_row_lifecycle.feature"),
  $bddFileMeta: ({}, use) => use(bddFileMeta),
});

const bddFileMeta = {
  "Row transitions status in real-time via SSE event": {"pickleLocation":"10:3","tags":["@realtime","@regression"]},
  "Stuck row with completed OCR renders as Ready to Review": {"pickleLocation":"15:3","tags":["@realtime","@regression"]},
};