import { Page } from '@playwright/test';

export class StorageHelper {
  constructor(private page: Page) {}

  /**
   * Set item in localStorage
   */
  async setLocalStorage(key: string, value: string): Promise<void> {
    await this.page.evaluate(
      ([k, v]) => localStorage.setItem(k, v),
      [key, value]
    );
  }

  /**
   * Get item from localStorage
   */
  async getLocalStorage(key: string): Promise<string | null> {
    return await this.page.evaluate((k) => localStorage.getItem(k), key);
  }

  /**
   * Remove item from localStorage
   */
  async removeLocalStorage(key: string): Promise<void> {
    await this.page.evaluate((k) => localStorage.removeItem(k), key);
  }

  /**
   * Set item in sessionStorage
   */
  async setSessionStorage(key: string, value: string): Promise<void> {
    await this.page.evaluate(
      ([k, v]) => sessionStorage.setItem(k, v),
      [key, value]
    );
  }

  /**
   * Get item from sessionStorage
   */
  async getSessionStorage(key: string): Promise<string | null> {
    return await this.page.evaluate((k) => sessionStorage.getItem(k), key);
  }

  /**
   * Clear all Munshi filter keys from sessionStorage
   */
  async clearSessionFilterKeys(): Promise<void> {
    const keys = [
      'ft_search',
      'ft_statusFilter',
      'ft_tallyStatusFilter',
      'ft_invoiceTypeFilter',
      'ft_dateFilter',
      'ft_activeTab',
    ];
    await this.page.evaluate((targetKeys) => {
      targetKeys.forEach((k) => sessionStorage.removeItem(k));
    }, keys);
  }

  /**
   * Clear tally push don't ask again setting
   */
  async clearTallyPushDontAskAgain(): Promise<void> {
    await this.removeLocalStorage('tallyPushDontAskAgain');
  }
}
