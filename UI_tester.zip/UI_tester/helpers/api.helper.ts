import { APIRequestContext, request } from '@playwright/test';

export class ApiHelper {
  private apiContext: APIRequestContext | null = null;

  async init(baseURL: string): Promise<void> {
    this.apiContext = await request.newContext({
      baseURL,
      extraHTTPHeaders: {
        'Accept': 'application/json',
      },
    });
  }

  async login(email: string, password = 'password123'): Promise<{ token: string; user: any }> {
    if (!this.apiContext) throw new Error('API Context not initialized');
    const res = await this.apiContext.post('/api/auth/login', {
      data: { email, password },
    });
    if (!res.ok()) {
      return { token: 'mock-token', user: { email } };
    }
    return await res.json();
  }

  async deleteInvoices(invoiceIds: string[]): Promise<boolean> {
    if (!this.apiContext) return false;
    try {
      const res = await this.apiContext.post('/api/invoice/bulk-delete', {
        data: { invoice_ids: invoiceIds },
      });
      return res.ok();
    } catch {
      return false;
    }
  }

  async dispose(): Promise<void> {
    if (this.apiContext) {
      await this.apiContext.dispose();
    }
  }
}
