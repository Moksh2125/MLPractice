import { Page } from '@playwright/test';

export interface InvoiceStatusEvent {
  invoice_id: string;
  status: string;
  tally_status?: string;
  company_id?: string;
}

export class SseHelper {
  constructor(private page: Page) {}

  /**
   * Inject simulated SSE event directly into window/eventSource
   */
  async simulateStatusEvent(eventData: InvoiceStatusEvent): Promise<void> {
    await this.page.evaluate((evt) => {
      // Dispatches custom window event or triggers registered SSE listeners
      const customEvent = new CustomEvent('munshi_sse_event', { detail: evt });
      window.dispatchEvent(customEvent);

      // If app attaches sseHandler to window:
      if ((window as any).__handleSseEvent) {
        (window as any).__handleSseEvent(evt);
      }
    }, eventData);
  }
}
