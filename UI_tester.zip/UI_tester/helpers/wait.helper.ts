import { Page, Locator, expect } from '@playwright/test';

export class WaitHelper {
  constructor(private page: Page) {}

  /**
   * Smart wait: polls until row status matches expected value without arbitrary sleep
   */
  async waitForRowStatus(
    rowLocator: Locator,
    expectedStatus: string,
    timeoutMs = 30_000
  ): Promise<void> {
    await expect(async () => {
      const badge = rowLocator.locator('[data-testid="status-badge"], .status-badge');
      const text = await badge.textContent();
      expect(text?.trim()).toContain(expectedStatus);
    }).toPass({ timeout: timeoutMs, intervals: [500, 1000, 2000] });
  }

  /**
   * Smart wait: waits for toast with specific text pattern
   */
  async waitForToast(
    pattern: string | RegExp,
    timeoutMs = 10_000
  ): Promise<string> {
    const toastLocator = this.page.locator('[role="alert"], .toast, .chakra-toast, .ant-notification-notice');
    await toastLocator.filter({ hasText: pattern }).first().waitFor({
      state: 'visible',
      timeout: timeoutMs,
    });
    return (await toastLocator.filter({ hasText: pattern }).first().innerText()).trim();
  }

  /**
   * Wait for network idle or specific URL response
   */
  async waitForApiResponse(
    urlSubstr: string,
    action: () => Promise<void>,
    timeoutMs = 15_000
  ): Promise<any> {
    const [response] = await Promise.all([
      this.page.waitForResponse((res) => res.url().includes(urlSubstr) && res.status() < 400, {
        timeout: timeoutMs,
      }),
      action(),
    ]);
    return await response.json();
  }

  /**
   * Wait for file download event and return suggested filename
   */
  async waitForFileDownload(
    triggerAction: () => Promise<void>
  ): Promise<{ filename: string; path: string }> {
    const [download] = await Promise.all([
      this.page.waitForEvent('download'),
      triggerAction(),
    ]);
    const filename = download.suggestedFilename();
    const path = await download.path() || '';
    return { filename, path };
  }
}
