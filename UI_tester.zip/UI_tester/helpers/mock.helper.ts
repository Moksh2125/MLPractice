import { Page, Route } from '@playwright/test';
import * as fs from 'fs';
import * as path from 'path';

export class MockHelper {
  constructor(private page: Page) {}

  /**
   * Mock the invoice list endpoint with custom data
   */
  async mockInvoiceList(fixtureName: string = 'invoice_list_all_states.json'): Promise<void> {
    const filePath = path.resolve(process.cwd(), 'fixtures/api', fixtureName);
    const mockData = JSON.parse(fs.readFileSync(filePath, 'utf-8'));

    await this.page.route('**/api/invoice/list*', async (route: Route) => {
      await route.fulfill({
        status: 200,
        contentType: 'application/json',
        body: JSON.stringify(mockData),
      });
    });
  }

  /**
   * Mock Tally push API with success
   */
  async mockPushSuccess(): Promise<void> {
    const filePath = path.resolve(process.cwd(), 'fixtures/api/push_success_response.json');
    const mockData = JSON.parse(fs.readFileSync(filePath, 'utf-8'));

    await this.page.route('**/api/invoice/push*', async (route: Route) => {
      await route.fulfill({
        status: 200,
        contentType: 'application/json',
        body: JSON.stringify(mockData),
      });
    });
  }

  /**
   * Mock Tally push API with error
   */
  async mockPushError(): Promise<void> {
    const filePath = path.resolve(process.cwd(), 'fixtures/api/push_tally_error_response.json');
    const mockData = JSON.parse(fs.readFileSync(filePath, 'utf-8'));

    await this.page.route('**/api/invoice/push*', async (route: Route) => {
      await route.fulfill({
        status: 400,
        contentType: 'application/json',
        body: JSON.stringify(mockData),
      });
    });
  }

  /**
   * Mock invoice status change (mark duplicate, reject)
   */
  async mockMarkStatus(): Promise<void> {
    await this.page.route('**/api/invoice/*/mark-status*', async (route: Route) => {
      await route.fulfill({
        status: 200,
        contentType: 'application/json',
        body: JSON.stringify({ success: true, message: 'Status updated' }),
      });
    });
  }

  /**
   * Mock delete invoice API
   */
  async mockDeleteInvoice(): Promise<void> {
    await this.page.route('**/api/invoice/delete*', async (route: Route) => {
      await route.fulfill({
        status: 200,
        contentType: 'application/json',
        body: JSON.stringify({ success: true, message: 'Invoices deleted successfully' }),
      });
    });
  }

  /**
   * Reset all intercepted routes
   */
  async unrouteAll(): Promise<void> {
    await this.page.unrouteAll({ behavior: 'ignoreErrors' });
  }
}
