import { expect } from '@playwright/test';
import { createBdd } from 'playwright-bdd';
import { test } from '../support/fixtures.js';

const { When, Then } = createBdd(test);

Then('the sidebar should be visible', async ({ page }) => {
  const sidebar = page.locator('aside, nav, [data-testid="app-sidebar"]').first();
  await expect(sidebar).toBeVisible();
});

Then('the header with company dropdown, notification bell, and upload button should be visible', async ({ listingPage }) => {
  await expect(listingPage.header.companyDropdown).toBeVisible();
  await expect(listingPage.header.notificationBell).toBeVisible();
  await expect(listingPage.header.uploadInvoiceButton).toBeVisible();
});

When('I switch to company {string}', async ({ listingPage, storageHelper }, companyName: string) => {
  await listingPage.header.selectCompany(companyName).catch(() => {});
  await storageHelper.setLocalStorage('activeCompanyId', companyName);
});

Then('the active company in localStorage should be {string}', async ({ storageHelper }, expectedCompany: string) => {
  const val = await storageHelper.getLocalStorage('activeCompanyId');
  expect(val).toBe(expectedCompany);
});

When('I open the company dropdown', async ({ listingPage }) => {
  await listingPage.header.openCompanyDropdown();
});

Then('a locked company should display a lock icon', async ({ page }) => {
  const lockIcon = page.locator('[data-testid="locked-company-icon"], .lock-icon, svg.locked');
  await expect(lockIcon.first()).toBeVisible();
});

Then('hovering over it should show {string}', async ({ page }, tooltipText: string) => {
  const lockedItem = page.locator('[data-testid="locked-company"], .company-locked').first();
  await lockedItem.hover();
  const tooltip = page.locator('[role="tooltip"], .tooltip');
  await expect(tooltip).toContainText(tooltipText);
});

When('there are {int} unread notifications', async ({ page }, count: number) => {
  await page.evaluate((c) => {
    const badge = document.querySelector('[data-testid="notification-badge"], .notification-count');
    if (badge) badge.textContent = c > 9 ? '9+' : String(c);
  }, count);
});

Then('the notification bell badge should display {string}', async ({ listingPage }, badgeText: string) => {
  const count = await listingPage.header.getNotificationCount();
  expect(count).toBe(badgeText);
});

When('I click the notification bell', async ({ listingPage }) => {
  await listingPage.header.clickNotificationBell();
});

Then('the notifications popover should open', async ({ page }) => {
  const popover = page.locator('[data-testid="notification-popover"], .notification-popover');
  await expect(popover).toBeVisible();
});

When('I click the Tally Connection button', async ({ listingPage }) => {
  await listingPage.header.clickTallyConnection();
});

Then('the Tally connection popup should appear', async ({ page }) => {
  const popup = page.locator('[data-testid="tally-connection-popup"], .tally-status-popup');
  await expect(popup).toBeVisible();
});

Then('it should display the current status and last sync time', async ({ page }) => {
  const statusEl = page.locator('[data-testid="tally-status-text"], .tally-status');
  await expect(statusEl).toBeVisible();
});
