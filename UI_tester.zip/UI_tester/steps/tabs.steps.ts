import { expect } from '@playwright/test';
import { createBdd } from 'playwright-bdd';
import { test } from '../support/fixtures.js';
import { TabName } from '../pages/ListingPage.js';

const { Given, When, Then } = createBdd(test);

Then('the Tally status tabs {string} should be visible', async ({ page }, tabList: string) => {
  const tabs = tabList.split(',').map((t) => t.trim());
  for (const tab of tabs) {
    const tabEl = page.locator(`[role="tab"]:has-text("${tab}"), button.tab-button:has-text("${tab}")`).first();
    await expect(tabEl).toBeVisible();
  }
});

Given('the page has {int} {string} invoices and {int} {string} invoices', async ({ page }, count1: number, status1: string, count2: number, status2: string) => {
  // Configured in mock data
});

When('I click the {string} tab', async ({ listingPage }, tabName: string) => {
  await listingPage.clickTab(tabName as TabName);
});

Then('the {string} tab count should remain unchanged', async ({ listingPage }, tabName: string) => {
  const count = await listingPage.getTabCount(tabName as TabName);
  expect(count).toBeGreaterThanOrEqual(0);
});

Then('the push button label should be {string}', async ({ listingPage }, expectedLabel: string) => {
  const label = await listingPage.getTallyPushLabel();
  expect(label).toBe(expectedLabel);
});

Then('rows with duplicate, rejected, and ocr_failed should appear', async ({ listingPage }) => {
  const rowCount = await listingPage.getRowCount();
  expect(rowCount).toBeGreaterThan(0);
});

Then('the tab count should include all three failed status types', async ({ listingPage }) => {
  const failedCount = await listingPage.getTabCount('Failed');
  expect(failedCount).toBeGreaterThanOrEqual(3);
});

Then('the Tally Status column filter should be reset', async ({ page }) => {
  const filter = page.locator('[data-testid="tally-status-column-filter"], select[name="tallyStatus"]');
  if (await filter.isVisible()) {
    await expect(filter).toHaveValue(/all/i);
  }
});

Then('the tab should show a processing spinner', async ({ page }) => {
  const spinner = page.locator('[data-testid="pushing-tab-spinner"], .tab-spinner, [aria-label="Loading"]');
  await expect(spinner.first()).toBeVisible();
});
