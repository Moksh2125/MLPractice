import { expect } from '@playwright/test';
import { createBdd } from 'playwright-bdd';
import { test } from '../support/fixtures.js';

const { Given, When, Then } = createBdd(test);

Then('the filter bar with search box and date filter should be visible', async ({ listingPage }) => {
  await expect(listingPage.searchInput).toBeVisible();
  await expect(listingPage.dateFilterPopover.triggerButton).toBeVisible();
});

When('I search for {string}', async ({ listingPage }, term: string) => {
  await listingPage.search(term);
});

When('I type {string} in the search box', async ({ listingPage }, term: string) => {
  await listingPage.search(term);
});

Then('only rows containing {string} case-insensitively should be shown', async ({ listingPage }, term: string) => {
  const rowCount = await listingPage.getRowCount();
  for (let i = 0; i < rowCount; i++) {
    const text = await listingPage.tableRows.nth(i).innerText();
    expect(text.toLowerCase()).toContain(term.toLowerCase());
  }
});

Given('the network is monitored for {string}', async ({ page }, urlPart: string) => {
  (page as any).__monitoredUrls = [];
  page.on('request', (req) => {
    if (req.url().includes(urlPart)) {
      (page as any).__monitoredUrls.push(req.url());
    }
  });
});

When('I select date range {string}', async ({ listingPage }, chipName: any) => {
  await listingPage.dateFilterPopover.open();
  await listingPage.dateFilterPopover.selectChip(chipName);
  await listingPage.dateFilterPopover.apply();
});

Then('no network request should be made to {string}', async ({ page }, urlPart: string) => {
  const requests = (page as any).__monitoredUrls || [];
  expect(requests.filter((u: string) => u.includes(urlPart)).length).toBe(0);
});

When('I open the date filter and choose {string}', async ({ listingPage }, option: any) => {
  await listingPage.dateFilterPopover.open();
  await listingPage.dateFilterPopover.selectChip(option);
});

When('I set the {string} date to {string}', async ({ listingPage }, field: string, dateVal: string) => {
  if (field === 'From') {
    await listingPage.dateFilterPopover.fromDateInput.fill(dateVal);
  } else {
    await listingPage.dateFilterPopover.toDateInput.fill(dateVal);
  }
});

Then('the {string} date field should be automatically cleared', async ({ listingPage }, field: string) => {
  if (field === 'To') {
    const val = await listingPage.dateFilterPopover.getToDateValue();
    expect(val).toBe('');
  }
});

Then('the table should only show rows matching the tab, search, and date range', async ({ listingPage }) => {
  const count = await listingPage.getRowCount();
  expect(count).toBeGreaterThanOrEqual(0);
});
