import { expect } from '@playwright/test';
import { createBdd } from 'playwright-bdd';
import { test } from '../support/fixtures.js';

const { Given, When, Then } = createBdd(test);

Then('the pagination controls should be visible', async ({ listingPage }) => {
  await expect(listingPage.paginationInfo).toBeVisible();
});

Given('I navigate to page {int}', async ({ listingPage }, pageNum: number) => {
  for (let i = 1; i < pageNum; i++) {
    await listingPage.nextPage();
  }
});

Then('I should be on page {int}', async ({ listingPage }, pageNum: number) => {
  const info = await listingPage.getPageInfo();
  expect(info.from).toBeGreaterThanOrEqual(1);
});

Then('the pagination info should show {string}', async ({ listingPage }, expectedInfo: string) => {
  await expect(listingPage.paginationInfo).toContainText(expectedInfo);
});

Then('the previous page button should be disabled', async ({ listingPage }) => {
  await expect(listingPage.prevPageButton).toBeDisabled();
});

Then('the previous page button should be enabled', async ({ listingPage }) => {
  await expect(listingPage.prevPageButton).toBeEnabled();
});

Then('the next page button should be enabled', async ({ listingPage }) => {
  await expect(listingPage.nextPageButton).toBeEnabled();
});

When('I click the next page button', async ({ listingPage }) => {
  await listingPage.nextPage();
});
