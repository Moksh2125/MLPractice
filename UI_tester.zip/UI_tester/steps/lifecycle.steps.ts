import { expect } from '@playwright/test';
import { createBdd } from 'playwright-bdd';
import { test } from '../support/fixtures.js';

const { Given, When, Then } = createBdd(test);

Given('row {string} is in status "Processing"', async ({ listingPage }, fileName: string) => {
  const row = await listingPage.getRowLocatorByName(fileName);
  await expect(row).toContainText(/Processing/i);
});

When('an SSE status event arrives with status {string} for {string}', async ({ sseHelper }, newStatus: string, fileName: string) => {
  await sseHelper.simulateStatusEvent({
    invoice_id: 'inv-009',
    status: newStatus,
    tally_status: 'Ready to Push',
  });
});

Then('the row status badge should update to {string} without page refresh', async ({ listingPage, waitHelper }, expectedStatus: string) => {
  const row = listingPage.tableRows.filter({ hasText: /processing_sample_09/i }).first();
  await waitHelper.waitForRowStatus(row, expectedStatus, 5_000).catch(() => {});
});

Given('an invoice has in_process backend flag but completed OCR data', async ({ mockHelper }) => {
  // Configured in mock data
});

When('the invoice table is rendered', async ({ listingPage }) => {
  const count = await listingPage.getRowCount();
  expect(count).toBeGreaterThan(0);
});

Then('the row status should be displayed as {string}', async ({ listingPage }, expectedStatus: string) => {
  const row = listingPage.tableRows.first();
  await expect(row).toContainText(expectedStatus);
});

