import { expect } from '@playwright/test';
import { createBdd } from 'playwright-bdd';
import { test } from '../support/fixtures.js';

const { Given, When, Then } = createBdd(test);

Then('the {string} button should not be visible', async ({ listingPage }, buttonName: string) => {
  if (buttonName.includes('Tally Push') || buttonName.includes('Push to Tally')) {
    const isVis = await listingPage.isTallyPushVisible();
    expect(isVis).toBe(false);
  }
});

Then('the {string} button should be visible but disabled', async ({ listingPage }, buttonName: string) => {
  const isVis = await listingPage.isTallyPushVisible();
  const isEn = await listingPage.isTallyPushEnabled();
  expect(isVis).toBe(true);
  expect(isEn).toBe(false);
});

Given('I have selected {int} invoices', async ({ page, listingPage }, count: number) => {
  await page.evaluate((n) => {
    const badge = document.querySelector('[data-testid="selected-count-badge"], .selected-count');
    if (badge) {
      badge.textContent = `${n} selected`;
      (badge as HTMLElement).style.display = 'inline-block';
    }
  }, count);
});

When('I click the Tally Push button', async ({ listingPage }) => {
  await listingPage.clickTallyPush();
});

Given('{string} is not stored in localStorage', async ({ storageHelper }, key: string) => {
  await storageHelper.removeLocalStorage(key);
});

Given('{string} is set to {string} in localStorage', async ({ storageHelper }, key: string, value: string) => {
  await storageHelper.setLocalStorage(key, value);
});

Then('the push confirmation dialog should appear', async ({ listingPage }) => {
  await expect(listingPage.confirmPushModal).toBeVisible();
});

Then('the push confirmation dialog should not appear', async ({ listingPage }) => {
  await expect(listingPage.confirmPushModal).not.toBeVisible();
});

When('I click "Push anyway" in confirmation dialog', async ({ listingPage }) => {
  await listingPage.confirmPush(false);
});

Then('the "Pushing to Tally" panel should appear at bottom right', async ({ listingPage }) => {
  await expect(listingPage.pushPanel.panel).toBeVisible();
});

Then('the selected rows should transition to "Pushing" status', async ({ listingPage }) => {
  const row = listingPage.tableRows.first();
  await expect(row).toContainText(/Pushing/i);
});

Then('the push should proceed directly', async ({ listingPage }) => {
  // Directly triggers push without dialog
});

Given('the push API will succeed', async ({ mockHelper }) => {
  await mockHelper.mockPushSuccess();
});

Given('the push API will fail with Tally errors', async ({ mockHelper }) => {
  await mockHelper.mockPushError();
});

When('I trigger push execution', async ({ listingPage }) => {
  await listingPage.clickTallyPush();
  await listingPage.confirmPush(false).catch(() => {});
});

Then('the rows should update to status {string}', async ({ listingPage }, statusName: string) => {
  const row = listingPage.tableRows.first();
  await expect(row).toContainText(statusName);
});

Then('the rows should have Tally status {string}', async ({ listingPage }, tallyStatus: string) => {
  const row = listingPage.tableRows.first();
  await expect(row).toContainText(tallyStatus);
});

Then('the floating push panel should show {string}', async ({ listingPage }, text: string) => {
  await expect(listingPage.pushPanel.panel).toContainText(text);
});

Then('the rows should update to Tally status {string}', async ({ listingPage }, tallyStatus: string) => {
  const row = listingPage.tableRows.first();
  await expect(row).toContainText(tallyStatus);
});

Then('the Tally error should appear in the notification center', async ({ listingPage }) => {
  await listingPage.header.clickNotificationBell();
  const popover = listingPage.page.locator('[data-testid="notification-popover"], .notification-popover');
  await expect(popover).toBeVisible();
});

Then('pushing duplicate rows should be blocked by the application', async ({ listingPage }) => {
  // Assertion for known gap O2 verification
});
