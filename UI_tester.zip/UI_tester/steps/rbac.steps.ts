import { expect } from '@playwright/test';
import { createBdd } from 'playwright-bdd';
import { test } from '../support/fixtures.js';

const { Given, Then } = createBdd(test);

Given('I am logged in as a sub-user without {string} permission', async ({ storageHelper }, permissionName: string) => {
  await storageHelper.setLocalStorage('user_role', 'subuser_restricted');
  await storageHelper.setLocalStorage(`perm_${permissionName}`, 'false');
});

Then('an error toast should indicate missing upload permission', async ({ listingPage }) => {
  const toastText = await listingPage.waitForToast(/permission|denied|cannot upload/i);
  expect(toastText).toBeTruthy();
});

Then('row delete trash icons should not be present in the table', async ({ listingPage }) => {
  const trashIcons = listingPage.page.locator('[data-testid="row-delete-button"], button.delete-btn');
  const count = await trashIcons.count();
  expect(count).toBe(0);
});
