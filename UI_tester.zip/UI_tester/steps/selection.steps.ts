import { expect } from '@playwright/test';
import { createBdd } from 'playwright-bdd';
import { test } from '../support/fixtures.js';

const { Given, When, Then } = createBdd(test);

Given('I select {int} invoice(s)', async ({ listingPage }, count: number) => {
  for (let i = 0; i < count; i++) {
    const row = listingPage.tableRows.nth(i);
    const cb = row.locator('input[type="checkbox"]');
    if (await cb.isEnabled()) {
      await cb.check();
    }
  }
});

Given('I select {int} invoices on the {string} tab', async ({ listingPage }, count: number, tabName: string) => {
  await listingPage.clickTab(tabName as any);
  for (let i = 0; i < count; i++) {
    const row = listingPage.tableRows.nth(i);
    const cb = row.locator('input[type="checkbox"]');
    if (await cb.isEnabled()) {
      await cb.check();
    }
  }
});

Given('a row with status {string} is selected on the {string} tab', async ({ listingPage }, statusName: string, tabName: string) => {
  await listingPage.clickTab(tabName as any);
  const row = listingPage.tableRows.filter({ hasText: statusName }).first();
  const cb = row.locator('input[type="checkbox"]');
  if (await cb.isEnabled()) {
    await cb.check();
  }
});

Then('the selection should be cleared', async ({ listingPage }) => {
  const count = await listingPage.getSelectedCount();
  expect(count).toBe(0);
});

Then('the selection count badge should disappear', async ({ listingPage }) => {
  const count = await listingPage.getSelectedCount();
  expect(count).toBe(0);
});

Then('the selected badge should still show {string}', async ({ listingPage }, expectedBadgeText: string) => {
  const count = await listingPage.getSelectedCount();
  const match = expectedBadgeText.match(/\d+/);
  const expectedNum = match ? parseInt(match[0], 10) : 0;
  expect(count).toBe(expectedNum);
});

When('I go to the next page', async ({ listingPage }) => {
  await listingPage.nextPage();
});

When('I change rows per page to {int}', async ({ listingPage }, rows: number) => {
  await listingPage.setRowsPerPage(rows);
});
