import { expect } from '@playwright/test';
import { createBdd } from 'playwright-bdd';
import { test } from '../support/fixtures.js';
import * as path from 'path';

const { Given, When, Then } = createBdd(test);

When('I click the Upload Invoice button in header', async ({ listingPage }) => {
  await listingPage.header.clickUploadInvoice();
});

When('I upload {string} as voucher type {string}', async ({ listingPage }, filename: string, voucherType: any) => {
  const filePath = path.resolve(process.cwd(), 'fixtures/invoices', filename);
  await listingPage.uploadModal.uploadFile(filePath, voucherType);
});

Then('the invoice should appear in the table with type badge {string}', async ({ page }, color: string) => {
  const badge = page.locator(`[data-testid="invoice-type-badge"].badge-${color}, .badge-${color}`).first();
  await expect(badge).toBeVisible();
});

Given('I have selected files in Single mode', async ({ listingPage }) => {
  const filePath = path.resolve(process.cwd(), 'fixtures/invoices/purchase_invoice.pdf');
  await listingPage.uploadModal.fileInput.setInputFiles(filePath);
});

When('I attempt to switch to Multiple mode', async ({ listingPage }) => {
  await listingPage.uploadModal.switchMode('Multiple').catch(() => {});
});

Then('the mode switch toggle should be disabled', async ({ listingPage }) => {
  const disabled = await listingPage.uploadModal.isModeToggleDisabled();
  expect(disabled).toBe(true);
});

Given('I have queued a file without selecting a voucher type', async ({ listingPage }) => {
  const filePath = path.resolve(process.cwd(), 'fixtures/invoices/purchase_invoice.pdf');
  await listingPage.uploadModal.fileInput.setInputFiles(filePath);
});

Then('the upload submit button should be disabled', async ({ listingPage }) => {
  const enabled = await listingPage.uploadModal.isUploadButtonEnabled();
  expect(enabled).toBe(false);
});

Then('a validation message {string} should appear', async ({ listingPage }, msg: string) => {
  await expect(listingPage.uploadModal.validationMessage).toContainText(msg);
});

When('I upload a duplicate invoice file', async ({ listingPage }) => {
  const filePath = path.resolve(process.cwd(), 'fixtures/invoices/purchase_invoice.pdf');
  await listingPage.uploadModal.uploadFile(filePath, 'Purchase');
});

Then('an error toast should mention {string}', async ({ listingPage }, errorText: string) => {
  const toastText = await listingPage.waitForToast(errorText);
  expect(toastText.toLowerCase()).toContain(errorText.toLowerCase());
});

