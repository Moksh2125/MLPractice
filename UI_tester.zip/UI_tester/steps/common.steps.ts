import { expect } from '@playwright/test';
import { createBdd } from 'playwright-bdd';
import { test } from '../support/fixtures.js';

const { Given, When, Then } = createBdd(test);

Given('I am logged in as the owner', async ({ mockHelper, storageHelper }) => {
  await storageHelper.setLocalStorage('auth_token', 'mock_owner_jwt_token');
  await storageHelper.setLocalStorage('user_role', 'owner');
  await mockHelper.mockInvoiceList('invoice_list_all_states.json');
});

Given('the invoice list is loaded with all status types', async ({ mockHelper }) => {
  await mockHelper.mockInvoiceList('invoice_list_all_states.json');
});

Given('the invoice list is loaded with 55 invoices', async ({ mockHelper }) => {
  await mockHelper.mockInvoiceList('invoice_list_large.json');
});

Given('I navigate to the Invoice Listing page', async ({ listingPage }) => {
  await listingPage.goto();
});

When('I reload the page', async ({ page }) => {
  await page.reload({ waitUntil: 'domcontentloaded' });
});

Then('a toast message {string} should appear', async ({ listingPage }, messageText: string) => {
  const toastText = await listingPage.waitForToast(messageText);
  expect(toastText.toLowerCase()).toContain(messageText.toLowerCase());
});

Then('an error toast should appear with {string}', async ({ listingPage }, errorText: string) => {
  const toastText = await listingPage.waitForToast(errorText);
  expect(toastText.toLowerCase()).toContain(errorText.toLowerCase());
});
