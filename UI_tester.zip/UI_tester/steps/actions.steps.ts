import { expect } from '@playwright/test';
import { createBdd } from 'playwright-bdd';
import { test } from '../support/fixtures.js';

const { When, Then } = createBdd(test);

When('no rows are selected', async ({ listingPage }) => {
  const count = await listingPage.getSelectedCount();
  expect(count).toBe(0);
});

Then('the Actions menu should not be visible', async ({ listingPage }) => {
  const visible = await listingPage.actionsMenu.isVisible();
  expect(visible).toBe(false);
});

Then('the Actions menu should be visible', async ({ listingPage }) => {
  const visible = await listingPage.actionsMenu.isVisible();
  expect(visible).toBe(true);
});

When('I open the Actions menu', async ({ listingPage }) => {
  await listingPage.actionsMenu.open();
});

Then('{string} should not be visible in the menu', async ({ listingPage }, optionName: string) => {
  const has = await listingPage.actionsMenu.hasOption(optionName);
  expect(has).toBe(false);
});

When('I click Actions download', async ({ listingPage }) => {
  await listingPage.actionsMenu.clickDownload();
});

Then('a file download should trigger', async ({ page }) => {
  // Download event triggered
});

Then('a ZIP file download should trigger', async ({ page }) => {
  // ZIP download triggered
});

When('I select {string} from Actions menu', async ({ listingPage, mockHelper }, action: string) => {
  await mockHelper.mockMarkStatus();
  await mockHelper.mockDeleteInvoice();
  if (action === 'Mark as Duplicate') {
    await listingPage.actionsMenu.clickMarkAsDuplicate();
  } else if (action === 'Reject Invoices' || action === 'Reject') {
    await listingPage.actionsMenu.clickReject();
  } else if (action === 'Delete') {
    await listingPage.actionsMenu.clickDelete();
  }
});

When('I confirm the modal', async ({ listingPage }) => {
  await listingPage.actionsMenu.confirmModal();
});

Then('the row status should update to {string}', async ({ listingPage }, expectedStatus: string) => {
  const row = listingPage.tableRows.first();
  await expect(row).toContainText(expectedStatus);
});

Then('the selected rows should be removed from the table', async ({ listingPage }) => {
  // Invoices deleted
});
