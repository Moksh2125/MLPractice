import { expect } from '@playwright/test';
import { createBdd } from 'playwright-bdd';
import { test } from '../support/fixtures.js';

const { When, Then } = createBdd(test);

When('I simulate navigating to review screen and returning', async ({ page, storageHelper }) => {
  await storageHelper.setSessionStorage('ft_search', 'Alpha');
  await page.goto('/review/inv-001', { waitUntil: 'commit' }).catch(() => {});
  await page.goto('/listing/invoices', { waitUntil: 'domcontentloaded' });
});

Then('the search box should retain value {string}', async ({ listingPage, storageHelper }, expectedValue: string) => {
  const sessionVal = await storageHelper.getSessionStorage('ft_search');
  if (sessionVal) {
    expect(sessionVal).toBe(expectedValue);
  } else {
    const val = await listingPage.searchInput.inputValue();
    expect(val).toBe(expectedValue);
  }
});

Then('company {string} should still be selected', async ({ storageHelper }, expectedCompany: string) => {
  const val = await storageHelper.getLocalStorage('activeCompanyId');
  expect(val).toBe(expectedCompany);
});

Then('the table column sort order should reset to default', async ({ page }) => {
  const sortedHeaders = page.locator('th[aria-sort]');
  const count = await sortedHeaders.count();
  expect(count).toBe(0);
});
