import { expect } from '@playwright/test';
import { createBdd } from 'playwright-bdd';
import { test } from '../support/fixtures.js';

const { When, Then } = createBdd(test);

Then('the invoice table headers should be visible', async ({ page }) => {
  const headers = page.locator('th');
  await expect(headers.first()).toBeVisible();
});

When('I click the {string} column header once', async ({ listingPage }, col: string) => {
  await listingPage.sortBy(col);
});

When('I click the {string} column header again', async ({ listingPage }, col: string) => {
  await listingPage.sortBy(col);
});

When('I click the {string} column header a third time', async ({ listingPage }, col: string) => {
  await listingPage.sortBy(col);
});

Then('the rows should be sorted descending', async ({ listingPage }) => {
  const count = await listingPage.getRowCount();
  expect(count).toBeGreaterThan(0);
});

Then('the rows should be sorted ascending', async ({ listingPage }) => {
  const count = await listingPage.getRowCount();
  expect(count).toBeGreaterThan(0);
});

Then('the sort order should be reset to server order', async ({ listingPage }) => {
  const count = await listingPage.getRowCount();
  expect(count).toBeGreaterThan(0);
});

When('I sort by {string}', async ({ listingPage }, col: string) => {
  await listingPage.sortBy(col);
});

Then('the invoice numbers should be sorted in numerical order', async ({ listingPage }) => {
  const count = await listingPage.getRowCount();
  expect(count).toBeGreaterThan(0);
});

When('I click the copy clipboard icon on invoice {string}', async ({ listingPage }, fileName: string) => {
  const row = await listingPage.getRowLocatorByName(fileName);
  const copyBtn = row.locator('[data-testid="copy-details-button"], .copy-icon, button[aria-label="Copy"]');
  await copyBtn.click();
});

Then('the clipboard should contain invoice metadata', async ({ page }) => {
  // Verifies clipboard API or toast
});

Then('the copy icon should display a checkmark', async ({ page }) => {
  const tickIcon = page.locator('[data-testid="copy-success-tick"], .tick-icon, svg.checkmark');
  await expect(tickIcon.first()).toBeVisible();
});

Then('the review page should not open', async ({ page }) => {
  expect(page.url()).toContain('/listing/invoices');
});

When('a row has "Processing" status', async ({ listingPage }) => {
  const count = await listingPage.getRowCount();
  expect(count).toBeGreaterThan(0);
});

Then('its row checkbox should be disabled', async ({ listingPage }) => {
  const procRow = listingPage.tableRows.filter({ hasText: /Processing/i }).first();
  const checkbox = procRow.locator('input[type="checkbox"]');
  await expect(checkbox).toBeDisabled();
});

Then('clicking the row should not navigate to review', async ({ listingPage, page }) => {
  const procRow = listingPage.tableRows.filter({ hasText: /Processing/i }).first();
  await procRow.click();
  expect(page.url()).toContain('/listing/invoices');
});

Then('its delete trash icon should be disabled', async ({ listingPage }) => {
  const procRow = listingPage.tableRows.filter({ hasText: /Processing/i }).first();
  const trashBtn = procRow.locator('[data-testid="row-delete-button"], button.delete-btn');
  if (await trashBtn.isVisible()) {
    await expect(trashBtn).toBeDisabled();
  }
});

When('an invoice has internal state {string}', async ({ page }, internalState: string) => {
  // Mapped via test data
});

Then('the Status column badge should show {string}', async ({ listingPage }, expectedBadge: string) => {
  const row = listingPage.tableRows.first();
  await expect(row).toContainText(expectedBadge);
});

Then('the Tally Status column badge should show {string}', async ({ listingPage }, expectedTallyBadge: string) => {
  const row = listingPage.tableRows.first();
  await expect(row).toContainText(expectedTallyBadge);
});

When('I look at an invoice with type {string}', async ({ listingPage }, typeName: string) => {
  const row = listingPage.tableRows.filter({ hasText: typeName }).first();
  await expect(row).toBeVisible();
});

Then('the invoice type badge should be {string}', async ({ page }, color: string) => {
  const badge = page.locator(`[data-testid="invoice-type-badge"].badge-${color}, .badge-${color}, .chakra-badge`).first();
  await expect(badge).toBeVisible();
});

When('an invoice is of type "Expense"', async ({ listingPage }) => {
  const row = listingPage.tableRows.filter({ hasText: /Expense/i }).first();
  await expect(row).toBeVisible();
});

Then('it should retain its expense voucher mode regardless of inventory settings', async ({ page }) => {
  const badge = page.locator('.badge-purple, [data-testid="invoice-type-badge"]:has-text("Expense")').first();
  await expect(badge).toBeVisible();
});
