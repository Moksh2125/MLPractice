@regression
Feature: Header Controls
  # PDF Section 4

  Background:
    Given I am logged in as the owner
    And I navigate to the Invoice Listing page

  Scenario: Switching company clears selection and reloads invoices
    Given I select 2 invoices
    When I switch to company "Alpha Enterprises"
    Then the selection should be cleared
    And the active company in localStorage should be "Alpha Enterprises"

  Scenario: Locked company displays warning tooltip and cannot be selected
    When I open the company dropdown
    Then a locked company should display a lock icon
    And hovering over it should show "This company is not active under your subscription plan"

  Scenario: Notification bell shows unread count and caps at 9+
    When there are 12 unread notifications
    Then the notification bell badge should display "9+"
    When I click the notification bell
    Then the notifications popover should open

  Scenario: Tally Connection popup displays connection status
    When I click the Tally Connection button
    Then the Tally connection popup should appear
    And it should display the current status and last sync time
