@regression
Feature: Invoice Types and Mode Badges
  # PDF Section 3 & 10

  Background:
    Given I am logged in as the owner
    And the invoice list is loaded with all status types

  Scenario Outline: Invoice type displays with correct visual badge
    When I look at an invoice with type "<type>"
    Then the invoice type badge should be "<color>"

    Examples:
      | type        | color  |
      | Purchase    | blue   |
      | Sales       | green  |
      | Credit Note | amber  |
      | Debit Note  | red    |
      | Expense     | purple |

  Scenario: Expense vouchers are treated as journal type vouchers
    When an invoice is of type "Expense"
    Then it should retain its expense voucher mode regardless of inventory settings
