@realtime @regression
Feature: Invoice Row Lifecycle and Real-Time SSE
  # PDF Section 14

  Background:
    Given I am logged in as the owner
    And the invoice list is loaded with all status types
    And I navigate to the Invoice Listing page

  Scenario: Row transitions status in real-time via SSE event
    Given row "processing_sample_09.pdf" is in status "Processing"
    When an SSE status event arrives with status "ready_to_review" for "processing_sample_09.pdf"
    Then the row status badge should update to "Ready to Review" without page refresh

  Scenario: Stuck row with completed OCR renders as Ready to Review
    Given an invoice has in_process backend flag but completed OCR data
    When the invoice table is rendered
    Then the row status should be displayed as "Ready to Review"
