@tabs @regression
Feature: Tally Status Tabs
  # PDF Section 5

  Background:
    Given I am logged in as the owner
    And the invoice list is loaded with all status types
    And I navigate to the Invoice Listing page

  Scenario: Tab counts are independent of filters
    Given the page has 5 "Ready to Review" invoices and 3 "Reviewed" invoices
    When I search for "Alpha Traders"
    Then the "Ready to Push" tab count should remain unchanged
    And the "Failed" tab count should remain unchanged

  Scenario: All tab hides Tally Push and duplicate/reject action menu items
    When I click the "All" tab
    Then the "Tally Push" button should not be visible
    When I select 1 invoice
    And I open the Actions menu
    Then "Mark as Duplicate" should not be visible in the menu
    And "Reject Invoices" should not be visible in the menu

  Scenario: Pushing to Tally tab disables the Tally Push button
    When I click the "Pushing to Tally" tab
    Then the "Tally Push" button should be visible but disabled
    And the tab should show a processing spinner

  Scenario: Pushed tab shows Re Push label
    When I click the "Pushed" tab
    And I select 1 invoice
    Then the push button label should be "Re Push to Tally (1)"

  Scenario: Failed tab includes duplicate, rejected, and OCR-failed rows
    When I click the "Failed" tab
    Then rows with duplicate, rejected, and ocr_failed should appear
    And the tab count should include all three failed status types

  Scenario: Clicking a tab resets page to 1 and clears Tally Status column filter
    Given I navigate to page 2
    When I click the "Ready to Push" tab
    Then I should be on page 1
    And the Tally Status column filter should be reset
