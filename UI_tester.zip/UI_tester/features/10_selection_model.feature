@regression
Feature: Row Selection Model and Persistence
  # PDF Section 11

  Background:
    Given I am logged in as the owner
    And the invoice list is loaded with all status types
    And I navigate to the Invoice Listing page

  Scenario: Row selection persists across tab switches
    Given I select 2 invoices
    When I click the "Pushed" tab
    Then the selected badge should still show "2 selected"

  Scenario: Selection is maintained across pagination navigation
    Given I select 1 invoice
    When I go to the next page
    Then the selected badge should still show "1 selected"

  Scenario: Changing rows per page resets selection
    Given I select 2 invoices
    When I change rows per page to 20
    Then the selection count badge should disappear

  Scenario: Switching company clears selection
    Given I select 1 invoice
    When I switch to company "Alpha Enterprises"
    Then the selection count badge should disappear
