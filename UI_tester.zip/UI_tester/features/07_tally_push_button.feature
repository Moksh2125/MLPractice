@push @regression
Feature: Tally Push Button and Execution Flow
  # PDF Section 8

  Background:
    Given I am logged in as the owner
    And the invoice list is loaded with all status types
    And I navigate to the Invoice Listing page

  Scenario: Attempting to push more than 50 invoices shows guard error toast
    Given I have selected 51 invoices
    When I click the Tally Push button
    Then an error toast should appear with "Select between 1 and 50 files to push to Tally"

  Scenario: Tally push with confirmation dialog
    Given "tallyPushDontAskAgain" is not stored in localStorage
    And I select 2 invoices
    When I click the Tally Push button
    Then the push confirmation dialog should appear
    When I click "Push anyway" in confirmation dialog
    Then the "Pushing to Tally" panel should appear at bottom right
    And the selected rows should transition to "Pushing" status

  Scenario: Tally push skips dialog when Don't ask again is set
    Given "tallyPushDontAskAgain" is set to "true" in localStorage
    And I select 1 invoice
    When I click the Tally Push button
    Then the push confirmation dialog should not appear
    And the push should proceed directly

  Scenario: Successful push updates rows to Reviewed and Pushed
    Given I select 2 invoices
    And the push API will succeed
    When I trigger push execution
    Then the rows should update to status "Reviewed"
    And the rows should have Tally status "Pushed"
    And the floating push panel should show "Synced to Tally"

  Scenario: Failed push updates rows to Failed and records errors
    Given I select 2 invoices
    And the push API will fail with Tally errors
    When I trigger push execution
    Then the rows should update to Tally status "Failed"
    And the Tally error should appear in the notification center
