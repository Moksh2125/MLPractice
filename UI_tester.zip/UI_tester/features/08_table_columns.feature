@regression
Feature: Table Columns Sorting and Row Interactions
  # PDF Section 9

  Background:
    Given I am logged in as the owner
    And the invoice list is loaded with all status types
    And I navigate to the Invoice Listing page

  Scenario: Sorting columns cycles through directions
    When I click the "File Name" column header once
    Then the rows should be sorted descending
    When I click the "File Name" column header again
    Then the rows should be sorted ascending
    When I click the "File Name" column header a third time
    Then the sort order should be reset to server order

  Scenario: Invoices sort numerically by invoice number
    When I sort by "Invoice No"
    Then the invoice numbers should be sorted in numerical order

  Scenario: Copy details icon copies invoice info without opening review screen
    When I click the copy clipboard icon on invoice "purchase_sample_01.pdf"
    Then the clipboard should contain invoice metadata
    And the copy icon should display a checkmark
    And the review page should not open

  Scenario: Processing rows are non-interactive
    When a row has "Processing" status
    Then its row checkbox should be disabled
    And clicking the row should not navigate to review
    And its delete trash icon should be disabled
