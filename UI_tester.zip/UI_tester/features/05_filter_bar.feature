@filters @regression
Feature: Filter Bar — Search and Date Filter
  # PDF Sections 6.1, 6.2

  Background:
    Given I am logged in as the owner
    And the invoice list is loaded with all status types
    And I navigate to the Invoice Listing page

  Scenario: Search is case-insensitive and resets pagination to page 1
    Given I navigate to page 2
    When I type "ALPHA" in the search box
    Then only rows containing "alpha" case-insensitively should be shown
    And I should be on page 1

  Scenario: Date filter is completely client-side without API calls
    Given the network is monitored for "/api/invoice/list"
    When I select date range "Last 7 Days"
    Then no network request should be made to "/api/invoice/list"

  Scenario: Custom date range clears To date if From is set after To
    When I open the date filter and choose "Custom Range"
    And I set the "From" date to "2026-11-15"
    And I set the "To" date to "2026-11-01"
    Then the "To" date field should be automatically cleared

  Scenario: Filters combine cumulatively with tab and search
    Given I click the "Ready to Push" tab
    When I type "Alpha" in the search box
    And I select date range "This Month"
    Then the table should only show rows matching the tab, search, and date range
