@regression
Feature: Status Badge Matrix
  # PDF Section 10

  Background:
    Given I am logged in as the owner
    And the invoice list is loaded with all status types
    And I navigate to the Invoice Listing page

  Scenario Outline: Internal invoice status maps to correct UI badges
    When an invoice has internal state "<internal_status>"
    Then the Status column badge should show "<status_badge>"
    And the Tally Status column badge should show "<tally_badge>"

    Examples:
      | internal_status      | status_badge           | tally_badge     |
      | uploaded             | Processing             | Extracting Data |
      | in_process           | Processing             | Extracting Data |
      | ready_to_review      | Ready to Review        | Ready to Push   |
      | reviewed             | Reviewed               | Ready to Push   |
      | duplicate            | Duplicate              | Ready to Push   |
      | rejected             | Rejected               | Ready to Push   |
      | duplicate_processing | Duplicate · Extracting | Ready to Push   |
      | failed               | Failed                 | Failed          |
      | ocr_failed           | Failed                 | N/A             |
