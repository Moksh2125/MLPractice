@regression
Feature: Actions Menu Bulk Operations
  # PDF Section 7

  Background:
    Given I am logged in as the owner
    And the invoice list is loaded with all status types
    And I navigate to the Invoice Listing page

  Scenario: Actions menu is hidden when no rows are selected
    When no rows are selected
    Then the Actions menu should not be visible

  Scenario: Actions menu appears when at least one row is selected
    When I select 1 invoice
    Then the Actions menu should be visible

  Scenario: Download single invoice starts direct file download
    Given I select 1 invoice
    When I click Actions download
    Then a file download should trigger
    And a toast message "Invoice downloaded successfully" should appear

  Scenario: Download multiple invoices triggers ZIP download
    Given I select 2 invoices
    When I click Actions download
    Then a ZIP file download should trigger
    And a toast message "invoices downloaded as ZIP" should appear

  Scenario: Mark as Duplicate updates row status and shows toast
    Given I click the "Ready to Push" tab
    And I select 1 invoice
    When I select "Mark as Duplicate" from Actions menu
    And I confirm the modal
    Then the row status should update to "Duplicate"
    And a toast message "marked as duplicate" should appear

  Scenario: Delete invoices removes rows and clears selection
    Given I select 2 invoices
    When I select "Delete" from Actions menu
    And I confirm the modal
    Then the selected rows should be removed from the table
    And the selection count badge should disappear
    And a toast message "deleted successfully" should appear
