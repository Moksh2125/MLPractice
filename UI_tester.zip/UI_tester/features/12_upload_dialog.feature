@upload @regression
Feature: Upload Invoice Dialog and Mode Controls
  # PDF Section 13

  Background:
    Given I am logged in as the owner
    And I navigate to the Invoice Listing page
    When I click the Upload Invoice button in header

  Scenario Outline: Upload invoice with voucher type displays correct badge
    When I upload "<filename>" as voucher type "<voucher_type>"
    Then the invoice should appear in the table with type badge "<badge_color>"

    Examples:
      | filename             | voucher_type | badge_color |
      | purchase_invoice.pdf | Purchase     | blue        |
      | sales_invoice.pdf    | Sales        | green       |
      | credit_note.pdf      | Credit Note  | amber       |
      | debit_note.pdf       | Debit Note   | red         |
      | expense_invoice.pdf  | Expense      | purple      |

  Scenario: Mode switch is locked when files are queued
    Given I have selected files in Single mode
    When I attempt to switch to Multiple mode
    Then the mode switch toggle should be disabled

  Scenario: Upload button is disabled when voucher type is omitted
    Given I have queued a file without selecting a voucher type
    Then the upload submit button should be disabled
    And a validation message "Please select a voucher type" should appear

  Scenario: Uploading duplicate invoice triggers duplicate lifecycle and toast
    When I upload a duplicate invoice file
    Then an error toast should mention "detected as a duplicate invoice"
    And the row status should update to "Duplicate"
