@pagination @regression
Feature: Table Pagination and Page Size
  # PDF Section 12

  Background:
    Given I am logged in as the owner
    And the invoice list is loaded with 55 invoices
    And I navigate to the Invoice Listing page

  Scenario: Pagination displays correct summary text
    Then the pagination info should show "1-10 of 55"
    And the previous page button should be disabled
    And the next page button should be enabled

  Scenario: Navigating to next page updates page summary
    When I click the next page button
    Then the pagination info should show "11-20 of 55"
    And the previous page button should be enabled

  Scenario: Changing rows per page recalculates page ranges and resets to page 1
    Given I click the next page button
    When I change rows per page to 20
    Then the pagination info should show "1-20 of 55"
