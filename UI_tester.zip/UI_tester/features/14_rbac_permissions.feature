@rbac @regression
Feature: Role-Based Access Control (RBAC) Permissions
  # PDF Section 15

  Scenario: User without push_to_tally right does not see push button
    Given I am logged in as a sub-user without "push_to_tally" permission
    And I navigate to the Invoice Listing page
    Then the "Tally Push" button should not be visible

  Scenario: User without upload_invoice right receives warning on upload attempt
    Given I am logged in as a sub-user without "upload_invoice" permission
    And I navigate to the Invoice Listing page
    When I click the Upload Invoice button in header
    Then an error toast should indicate missing upload permission

  Scenario: User without transfer_invoice cannot see Transfer action
    Given I am logged in as a sub-user without "transfer_invoice" permission
    And I navigate to the Invoice Listing page
    When I select 1 invoice
    And I open the Actions menu
    Then "Transfer" should not be visible in the menu

  Scenario: User without delete_invoice right cannot delete rows
    Given I am logged in as a sub-user without "delete_invoice" permission
    And I navigate to the Invoice Listing page
    When I select 1 invoice
    And I open the Actions menu
    Then "Delete" should not be visible in the menu
    And row delete trash icons should not be present in the table
