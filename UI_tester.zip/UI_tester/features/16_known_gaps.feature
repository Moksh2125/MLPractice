@known-gap
Feature: Known Product Gaps (O1-O11) Tracking
  # PDF Section 17 & Plan Section 9

  Background:
    Given I am logged in as the owner
    And the invoice list is loaded with all status types
    And I navigate to the Invoice Listing page

  @O2
  Scenario: Duplicate rows push block verification (Known Gap O2)
    # PDF O2: In staging, duplicate invoices on Failed tab can technically be pushed
    Given a row with status "Duplicate" is selected on the "Failed" tab
    When I click the Tally Push button
    Then pushing duplicate rows should be blocked by the application

  @O3
  Scenario: Selection persistence across tab change (Known Behavior O3)
    Given I select 2 invoices on the "Ready to Push" tab
    When I click the "Pushed" tab
    Then the selected badge should still show "2 selected"

  @O7
  Scenario: Multi-page selection with 50-limit guard (Known Behavior O7)
    Given I have selected 51 invoices
    When I click the Tally Push button
    Then an error toast should appear with "Select between 1 and 50 files to push to Tally"
