@smoke @regression
Feature: Page Anatomy and Layout
  # PDF Section 2 & 1

  Background:
    Given I am logged in as the owner
    And I navigate to the Invoice Listing page

  Scenario: All core UI sections are visible
    Then the sidebar should be visible
    And the header with company dropdown, notification bell, and upload button should be visible
    And the Tally status tabs "All, Ready to Push, Pushing to Tally, Pushed, Failed" should be visible
    And the filter bar with search box and date filter should be visible
    And the invoice table headers should be visible
    And the pagination controls should be visible
