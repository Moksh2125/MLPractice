@regression
Feature: State Persistence and Session Storage
  # PDF Section 16

  Background:
    Given I am logged in as the owner
    And the invoice list is loaded with all status types
    And I navigate to the Invoice Listing page

  Scenario: Search query is preserved across review screen navigation
    Given I type "Alpha" in the search box
    When I simulate navigating to review screen and returning
    Then the search box should retain value "Alpha"

  Scenario: Active company persists in local storage across page reloads
    Given I switch to company "Alpha Enterprises"
    When I reload the page
    Then company "Alpha Enterprises" should still be selected

  Scenario: Column sort order resets to default on page refresh
    Given I click the "File Name" column header once
    When I reload the page
    Then the table column sort order should reset to default
