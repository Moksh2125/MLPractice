export interface CucumberWorldContext {
  activeCompany?: string;
  selectedInvoiceIds?: string[];
  lastErrorToast?: string;
  downloadedFiles?: string[];
}
