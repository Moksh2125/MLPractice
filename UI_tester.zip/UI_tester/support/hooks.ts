import { createBdd } from 'playwright-bdd';
import { test } from './fixtures.js';

const { Before, After } = createBdd(test);

Before(async ({ page, storageHelper }) => {
  // Navigate to blank or origin to clear storage before scenario
  await page.goto('/listing/invoices', { waitUntil: 'commit' }).catch(() => {});
  await storageHelper.clearSessionFilterKeys().catch(() => {});
  await storageHelper.clearTallyPushDontAskAgain().catch(() => {});
});

After(async ({ page }, testInfo) => {
  if (testInfo.status !== testInfo.expectedStatus) {
    const screenshot = await page.screenshot({ fullPage: true }).catch(() => null);
    if (screenshot) {
      await testInfo.attach('screenshot-on-failure', {
        body: screenshot,
        contentType: 'image/png',
      });
    }
  }
});
