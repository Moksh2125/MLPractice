import { test as base, createBdd } from 'playwright-bdd';
import { ListingPage } from '../pages/ListingPage.js';
import { MockHelper } from '../helpers/mock.helper.js';
import { StorageHelper } from '../helpers/storage.helper.js';
import { SseHelper } from '../helpers/sse.helper.js';
import { WaitHelper } from '../helpers/wait.helper.js';
import { ApiHelper } from '../helpers/api.helper.js';

type CustomFixtures = {
  listingPage: ListingPage;
  mockHelper: MockHelper;
  storageHelper: StorageHelper;
  sseHelper: SseHelper;
  waitHelper: WaitHelper;
  apiHelper: ApiHelper;
};

export const test = base.extend<CustomFixtures>({
  listingPage: async ({ page }, use) => {
    const lp = new ListingPage(page);
    await use(lp);
  },
  mockHelper: async ({ page }, use) => {
    const mock = new MockHelper(page);
    await use(mock);
  },
  storageHelper: async ({ page }, use) => {
    const storage = new StorageHelper(page);
    await use(storage);
  },
  sseHelper: async ({ page }, use) => {
    const sse = new SseHelper(page);
    await use(sse);
  },
  waitHelper: async ({ page }, use) => {
    const wait = new WaitHelper(page);
    await use(wait);
  },
  apiHelper: async ({ baseURL }, use) => {
    const api = new ApiHelper();
    if (baseURL) {
      await api.init(baseURL);
    }
    await use(api);
    await api.dispose();
  },
});

export const { Given, When, Then } = createBdd(test);
