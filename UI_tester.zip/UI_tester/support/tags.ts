/**
 * Standard test tags for Munshi UI testing suite
 */
export const Tags = {
  SMOKE: '@smoke',
  REGRESSION: '@regression',
  RBAC: '@rbac',
  UPLOAD: '@upload',
  PUSH: '@push',
  FILTERS: '@filters',
  TABS: '@tabs',
  PAGINATION: '@pagination',
  REALTIME: '@realtime',
  KNOWN_GAP: '@known-gap',
  SKIP: '@skip',
} as const;

export type TagType = typeof Tags[keyof typeof Tags];
