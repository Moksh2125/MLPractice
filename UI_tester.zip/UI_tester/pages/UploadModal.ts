import { Page, Locator } from '@playwright/test';

export class UploadModal {
  readonly modal: Locator;
  readonly modeToggleSingle: Locator;
  readonly modeToggleMultiple: Locator;
  readonly voucherTypeSelect: Locator;
  readonly fileInput: Locator;
  readonly dropZone: Locator;
  readonly uploadSubmitButton: Locator;
  readonly closeButton: Locator;
  readonly validationMessage: Locator;

  constructor(private page: Page) {
    this.modal = page.locator('[role="dialog"]:has-text("Upload"), [data-testid="upload-modal"]');
    this.modeToggleSingle = page.locator('[data-testid="mode-single"], button:has-text("Single")');
    this.modeToggleMultiple = page.locator('[data-testid="mode-multiple"], button:has-text("Multiple")');
    this.voucherTypeSelect = page.locator('[data-testid="voucher-type-select"], select[name="voucherType"]');
    this.fileInput = page.locator('input[type="file"]');
    this.dropZone = page.locator('[data-testid="upload-dropzone"], .upload-dropzone');
    this.uploadSubmitButton = page.locator('[data-testid="upload-submit-button"], button:has-text("Upload")');
    this.closeButton = page.locator('[data-testid="modal-close-button"], [aria-label="Close"]');
    this.validationMessage = page.locator('[data-testid="upload-validation-error"], .error-message');
  }

  async isVisible(): Promise<boolean> {
    return await this.modal.isVisible();
  }

  async switchMode(mode: 'Single' | 'Multiple'): Promise<void> {
    if (mode === 'Single') {
      await this.modeToggleSingle.click();
    } else {
      await this.modeToggleMultiple.click();
    }
  }

  async isModeToggleDisabled(): Promise<boolean> {
    return (await this.modeToggleMultiple.isDisabled()) || (await this.modeToggleSingle.isDisabled());
  }

  async selectVoucherType(voucherType: 'Purchase' | 'Sales' | 'Credit Note' | 'Debit Note' | 'Expense'): Promise<void> {
    await this.voucherTypeSelect.selectOption({ label: voucherType });
  }

  async uploadFile(filePath: string, voucherType?: 'Purchase' | 'Sales' | 'Credit Note' | 'Debit Note' | 'Expense'): Promise<void> {
    if (voucherType) {
      await this.selectVoucherType(voucherType);
    }
    await this.fileInput.setInputFiles(filePath);
    await this.uploadSubmitButton.click();
  }

  async isUploadButtonEnabled(): Promise<boolean> {
    return await this.uploadSubmitButton.isEnabled();
  }

  async close(): Promise<void> {
    await this.closeButton.click();
  }
}
