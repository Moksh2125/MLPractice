import { Page, Locator } from '@playwright/test';

export class TransferDialog {
  readonly dialog: Locator;
  readonly companySelect: Locator;
  readonly transferButton: Locator;
  readonly cancelButton: Locator;

  constructor(private page: Page) {
    this.dialog = page.locator('[role="dialog"]:has-text("Transfer"), [data-testid="transfer-modal"]');
    this.companySelect = page.locator('[data-testid="target-company-select"], select[name="targetCompany"]');
    this.transferButton = page.locator('[data-testid="transfer-submit-button"], button:has-text("Transfer")');
    this.cancelButton = page.locator('[data-testid="transfer-cancel-button"], button:has-text("Cancel")');
  }

  async isVisible(): Promise<boolean> {
    return await this.dialog.isVisible();
  }

  async selectTargetCompany(companyName: string): Promise<void> {
    await this.companySelect.selectOption({ label: companyName });
  }

  async confirmTransfer(): Promise<void> {
    await this.transferButton.click();
  }
}
