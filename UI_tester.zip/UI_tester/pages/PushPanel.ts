import { Page, Locator } from '@playwright/test';

export class PushPanel {
  readonly panel: Locator;
  readonly title: Locator;
  readonly progressRows: Locator;
  readonly minimizeButton: Locator;
  readonly closeButton: Locator;

  constructor(private page: Page) {
    this.panel = page.locator('[data-testid="pushing-tally-panel"], .pushing-to-tally-panel');
    this.title = page.locator('[data-testid="push-panel-title"], .panel-header');
    this.progressRows = page.locator('[data-testid="push-panel-row"], .push-progress-item');
    this.minimizeButton = page.locator('[data-testid="push-panel-minimize"], button[aria-label="Minimize"]');
    this.closeButton = page.locator('[data-testid="push-panel-close"], button[aria-label="Close"]');
  }

  async isVisible(): Promise<boolean> {
    return await this.panel.isVisible();
  }

  async getRowCount(): Promise<number> {
    return await this.progressRows.count();
  }

  async hasStatusForInvoice(fileName: string, expectedStatus: string): Promise<boolean> {
    const row = this.progressRows.filter({ hasText: fileName });
    return await row.locator(`text=${expectedStatus}`).isVisible();
  }
}
