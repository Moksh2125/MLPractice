import { Page, Locator } from '@playwright/test';

export class Header {
  readonly companyDropdown: Locator;
  readonly companySearchInput: Locator;
  readonly notificationBell: Locator;
  readonly notificationBadge: Locator;
  readonly syncStatusIndicator: Locator;
  readonly tallyConnectionButton: Locator;
  readonly uploadInvoiceButton: Locator;

  constructor(private page: Page) {
    this.companyDropdown = page.locator('[data-testid="company-dropdown"], button:has-text("Company")').first();
    this.companySearchInput = page.locator('[data-testid="company-search-input"], input[placeholder*="Search company"]');
    this.notificationBell = page.locator('[data-testid="notification-bell"], button[aria-label="Notifications"]');
    this.notificationBadge = page.locator('[data-testid="notification-badge"], .notification-count');
    this.syncStatusIndicator = page.locator('[data-testid="sync-status"], .sync-status');
    this.tallyConnectionButton = page.locator('[data-testid="tally-connection-button"], button:has-text("Tally")');
    this.uploadInvoiceButton = page.locator('[data-testid="upload-invoice-button"], button:has-text("Upload Invoice")');
  }

  async openCompanyDropdown(): Promise<void> {
    await this.companyDropdown.click();
  }

  async selectCompany(companyName: string): Promise<void> {
    await this.openCompanyDropdown();
    if (await this.companySearchInput.isVisible()) {
      await this.companySearchInput.fill(companyName);
    }
    await this.page.locator(`[role="option"]:has-text("${companyName}"), .company-item:has-text("${companyName}")`).first().click();
  }

  async getNotificationCount(): Promise<string> {
    if (await this.notificationBadge.isVisible()) {
      return (await this.notificationBadge.innerText()).trim();
    }
    return '0';
  }

  async clickNotificationBell(): Promise<void> {
    await this.notificationBell.click();
  }

  async clickTallyConnection(): Promise<void> {
    await this.tallyConnectionButton.click();
  }

  async clickUploadInvoice(): Promise<void> {
    await this.uploadInvoiceButton.click();
  }
}
