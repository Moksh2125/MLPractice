import { Page, Locator } from '@playwright/test';

export class ActionsMenu {
  readonly menuButton: Locator;
  readonly menuDropdown: Locator;
  readonly downloadOption: Locator;
  readonly transferOption: Locator;
  readonly markDuplicateOption: Locator;
  readonly rejectOption: Locator;
  readonly deleteOption: Locator;
  readonly confirmDialog: Locator;
  readonly confirmDialogButton: Locator;

  constructor(private page: Page) {
    this.menuButton = page.locator('[data-testid="actions-menu-button"], button:has-text("Actions")');
    this.menuDropdown = page.locator('[data-testid="actions-menu-dropdown"], [role="menu"]');
    this.downloadOption = page.locator('[data-testid="action-download"], [role="menuitem"]:has-text("Download")');
    this.transferOption = page.locator('[data-testid="action-transfer"], [role="menuitem"]:has-text("Transfer")');
    this.markDuplicateOption = page.locator('[data-testid="action-mark-duplicate"], [role="menuitem"]:has-text("Mark as Duplicate")');
    this.rejectOption = page.locator('[data-testid="action-reject"], [role="menuitem"]:has-text("Reject")');
    this.deleteOption = page.locator('[data-testid="action-delete"], [role="menuitem"]:has-text("Delete")');
    this.confirmDialog = page.locator('[role="dialog"], [data-testid="confirmation-modal"]');
    this.confirmDialogButton = page.locator('[data-testid="modal-confirm-button"], [role="dialog"] button:has-text("Confirm"), [role="dialog"] button:has-text("Delete"), [role="dialog"] button:has-text("Yes")');
  }

  async isVisible(): Promise<boolean> {
    return await this.menuButton.isVisible();
  }

  async open(): Promise<void> {
    await this.menuButton.click();
    await this.menuDropdown.waitFor({ state: 'visible' });
  }

  async hasOption(optionName: string): Promise<boolean> {
    const item = this.page.locator(`[role="menuitem"]:has-text("${optionName}")`);
    return await item.isVisible();
  }

  async clickDownload(): Promise<void> {
    await this.open();
    await this.downloadOption.click();
  }

  async clickTransfer(): Promise<void> {
    await this.open();
    await this.transferOption.click();
  }

  async clickMarkAsDuplicate(): Promise<void> {
    await this.open();
    await this.markDuplicateOption.click();
  }

  async clickReject(): Promise<void> {
    await this.open();
    await this.rejectOption.click();
  }

  async clickDelete(): Promise<void> {
    await this.open();
    await this.deleteOption.click();
  }

  async confirmModal(): Promise<void> {
    await this.confirmDialog.waitFor({ state: 'visible' });
    await this.confirmDialogButton.click();
  }
}
