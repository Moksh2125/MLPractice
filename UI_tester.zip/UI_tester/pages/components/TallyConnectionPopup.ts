import { Page, Locator } from '@playwright/test';

export class TallyConnectionPopup {
  readonly triggerButton: Locator;
  readonly popup: Locator;
  readonly connectionStatusText: Locator;
  readonly lastSyncedText: Locator;
  readonly reconnectButton: Locator;

  constructor(private page: Page) {
    this.triggerButton = page.locator('[data-testid="tally-connection-button"], button:has-text("Tally")');
    this.popup = page.locator('[data-testid="tally-connection-popup"], .tally-status-popup');
    this.connectionStatusText = page.locator('[data-testid="tally-status-text"], .tally-status');
    this.lastSyncedText = page.locator('[data-testid="tally-last-synced"], .tally-last-sync');
    this.reconnectButton = page.locator('[data-testid="tally-reconnect-button"], button:has-text("Reconnect")');
  }

  async open(): Promise<void> {
    await this.triggerButton.click();
    await this.popup.waitFor({ state: 'visible' });
  }

  async getStatus(): Promise<string> {
    return (await this.connectionStatusText.innerText()).trim();
  }

  async isConnected(): Promise<boolean> {
    const status = await this.getStatus();
    return /connected|online/i.test(status);
  }
}
