import { Page, Locator } from '@playwright/test';

export class DateFilterPopover {
  readonly triggerButton: Locator;
  readonly popover: Locator;
  readonly dateTypeSelector: Locator;
  readonly fromDateInput: Locator;
  readonly toDateInput: Locator;
  readonly applyButton: Locator;
  readonly resetButton: Locator;

  constructor(private page: Page) {
    this.triggerButton = page.locator('[data-testid="date-filter-button"], button:has-text("Date")');
    this.popover = page.locator('[data-testid="date-filter-popover"], .date-filter-popover');
    this.dateTypeSelector = page.locator('[data-testid="date-type-select"], select[name="dateType"]');
    this.fromDateInput = page.locator('[data-testid="date-from-input"], input[placeholder*="From"]');
    this.toDateInput = page.locator('[data-testid="date-to-input"], input[placeholder*="To"]');
    this.applyButton = page.locator('[data-testid="date-filter-apply"], button:has-text("Apply")');
    this.resetButton = page.locator('[data-testid="date-filter-reset"], button:has-text("Reset")');
  }

  async open(): Promise<void> {
    await this.triggerButton.click();
    await this.popover.waitFor({ state: 'visible' });
  }

  async selectDateType(dateType: 'Invoice Date' | 'Upload Date' | 'Reviewed Date' | 'Push Date'): Promise<void> {
    await this.dateTypeSelector.selectOption({ label: dateType });
  }

  async selectChip(chipName: 'Today' | 'Yesterday' | 'This Week' | 'Last 7 Days' | 'This Month' | 'All Dates' | 'Custom Range'): Promise<void> {
    await this.page.locator(`button:has-text("${chipName}"), [data-testid="chip-${chipName.toLowerCase().replace(/\s+/g, '-')}"]`).first().click();
  }

  async setCustomRange(from: string, to: string): Promise<void> {
    await this.selectChip('Custom Range');
    await this.fromDateInput.fill(from);
    await this.toDateInput.fill(to);
  }

  async getToDateValue(): Promise<string> {
    return await this.toDateInput.inputValue();
  }

  async apply(): Promise<void> {
    await this.applyButton.click();
  }
}
