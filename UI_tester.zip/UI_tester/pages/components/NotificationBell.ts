import { Page, Locator } from '@playwright/test';

export class NotificationBell {
  readonly bellButton: Locator;
  readonly popover: Locator;
  readonly unreadBadge: Locator;
  readonly items: Locator;

  constructor(private page: Page) {
    this.bellButton = page.locator('[data-testid="notification-bell"], button[aria-label="Notifications"]');
    this.popover = page.locator('[data-testid="notification-popover"], .notification-popover');
    this.unreadBadge = page.locator('[data-testid="notification-badge"], .notification-count');
    this.items = page.locator('[data-testid="notification-item"], .notification-item');
  }

  async open(): Promise<void> {
    await this.bellButton.click();
    await this.popover.waitFor({ state: 'visible' });
  }

  async getUnreadCount(): Promise<string> {
    if (await this.unreadBadge.isVisible()) {
      return (await this.unreadBadge.innerText()).trim();
    }
    return '0';
  }

  async getItemTexts(): Promise<string[]> {
    return await this.items.allInnerTexts();
  }
}
