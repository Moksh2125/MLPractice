import { Page, Locator, expect } from '@playwright/test';
import { Header } from './components/Header.js';
import { DateFilterPopover } from './components/DateFilterPopover.js';
import { ActionsMenu } from './components/ActionsMenu.js';
import { UploadModal } from './UploadModal.js';
import { TransferDialog } from './TransferDialog.js';
import { PushPanel } from './PushPanel.js';

export type TabName = 'All' | 'Ready to Push' | 'Pushing to Tally' | 'Pushed' | 'Failed';

export interface RowInfo {
  id?: string;
  name: string;
  invoiceNo: string;
  invoiceDate: string;
  sellerName: string;
  amount: string;
  uploadDate: string;
  invoiceType: string;
  status: string;
  tallyStatus: string;
  isSelectable: boolean;
  isClickable: boolean;
}

export class ListingPage {
  readonly page: Page;
  readonly header: Header;
  readonly actionsMenu: ActionsMenu;
  readonly uploadModal: UploadModal;
  readonly transferDialog: TransferDialog;
  readonly pushPanel: PushPanel;
  readonly dateFilterPopover: DateFilterPopover;

  // Filter bar locators
  readonly searchInput: Locator;
  readonly selectedBadge: Locator;
  readonly tallyPushButton: Locator;
  readonly confirmPushModal: Locator;
  readonly confirmPushDontAskCheckbox: Locator;
  readonly confirmPushSubmitButton: Locator;

  // Table locators
  readonly selectAllCheckbox: Locator;
  readonly tableRows: Locator;

  // Pagination locators
  readonly paginationInfo: Locator;
  readonly rowsPerPageSelect: Locator;
  readonly prevPageButton: Locator;
  readonly nextPageButton: Locator;

  constructor(page: Page) {
    this.page = page;
    this.header = new Header(page);
    this.actionsMenu = new ActionsMenu(page);
    this.uploadModal = new UploadModal(page);
    this.transferDialog = new TransferDialog(page);
    this.pushPanel = new PushPanel(page);
    this.dateFilterPopover = new DateFilterPopover(page);

    this.searchInput = page.locator('[data-testid="invoice-search-input"], input[placeholder*="Search by invoice"]');
    this.selectedBadge = page.locator('[data-testid="selected-count-badge"], .selected-count');
    this.tallyPushButton = page.locator('[data-testid="tally-push-button"], button:has-text("Push to Tally"), button:has-text("Re Push to Tally")');
    this.confirmPushModal = page.locator('[role="dialog"]:has-text("Push"), [data-testid="confirm-push-modal"]');
    this.confirmPushDontAskCheckbox = page.locator('[data-testid="dont-ask-again-checkbox"], input[type="checkbox"]#dontAskAgain');
    this.confirmPushSubmitButton = page.locator('[data-testid="confirm-push-submit"], button:has-text("Push anyway"), button:has-text("Confirm Push")');

    this.selectAllCheckbox = page.locator('th input[type="checkbox"], [data-testid="select-all-checkbox"]');
    this.tableRows = page.locator('tbody tr, [data-testid="invoice-row"]');

    this.paginationInfo = page.locator('[data-testid="pagination-info"], .pagination-summary');
    this.rowsPerPageSelect = page.locator('[data-testid="rows-per-page-select"], select[aria-label="Rows per page"]');
    this.prevPageButton = page.locator('[data-testid="pagination-prev"], button[aria-label="Previous page"]');
    this.nextPageButton = page.locator('[data-testid="pagination-next"], button[aria-label="Next page"]');
  }

  async goto(companyId?: string): Promise<void> {
    const url = companyId ? `/listing/invoices?company=${companyId}` : '/listing/invoices';
    await this.page.goto(url, { waitUntil: 'domcontentloaded' });
  }

  async clickTab(tab: TabName): Promise<void> {
    const tabLocator = this.page.locator(`[role="tab"]:has-text("${tab}"), button.tab-button:has-text("${tab}")`).first();
    await tabLocator.click();
  }

  async getTabCount(tab: TabName): Promise<number> {
    const tabLocator = this.page.locator(`[role="tab"]:has-text("${tab}"), button.tab-button:has-text("${tab}")`).first();
    const badge = tabLocator.locator('.count-badge, .chakra-badge, span').last();
    const text = await badge.innerText();
    return parseInt(text.replace(/[^0-9]/g, ''), 10) || 0;
  }

  async getActiveTab(): Promise<string> {
    const active = this.page.locator('[role="tab"][aria-selected="true"], button.tab-button.active');
    return (await active.innerText()).trim();
  }

  async search(query: string): Promise<void> {
    await this.searchInput.fill(query);
  }

  async getSelectedCount(): Promise<number> {
    if (await this.selectedBadge.isVisible()) {
      const text = await this.selectedBadge.innerText();
      const match = text.match(/\d+/);
      return match ? parseInt(match[0], 10) : 0;
    }
    return 0;
  }

  async isTallyPushVisible(): Promise<boolean> {
    return await this.tallyPushButton.isVisible();
  }

  async isTallyPushEnabled(): Promise<boolean> {
    return await this.tallyPushButton.isEnabled();
  }

  async getTallyPushLabel(): Promise<string> {
    return (await this.tallyPushButton.innerText()).trim();
  }

  async clickTallyPush(): Promise<void> {
    await this.tallyPushButton.click();
  }

  async confirmPush(dontAskAgain = false): Promise<void> {
    if (await this.confirmPushModal.isVisible()) {
      if (dontAskAgain && (await this.confirmPushDontAskCheckbox.isVisible())) {
        await this.confirmPushDontAskCheckbox.check();
      }
      await this.confirmPushSubmitButton.click();
    }
  }

  async getRowCount(): Promise<number> {
    return await this.tableRows.count();
  }

  async getRowLocatorByName(fileName: string): Promise<Locator> {
    return this.tableRows.filter({ hasText: fileName }).first();
  }

  async selectRow(fileName: string): Promise<void> {
    const row = await this.getRowLocatorByName(fileName);
    const checkbox = row.locator('input[type="checkbox"]');
    await checkbox.check();
  }

  async selectAllOnPage(): Promise<void> {
    await this.selectAllCheckbox.check();
  }

  async clickRow(fileName: string): Promise<void> {
    const row = await this.getRowLocatorByName(fileName);
    await row.click();
  }

  async sortBy(columnName: string): Promise<void> {
    const header = this.page.locator(`th:has-text("${columnName}")`);
    await header.click();
  }

  async getPageInfo(): Promise<{ from: number; to: number; total: number }> {
    const text = await this.paginationInfo.innerText();
    const match = text.match(/(\d+)\s*-\s*(\d+)\s+of\s+(\d+)/i);
    if (match) {
      return {
        from: parseInt(match[1], 10),
        to: parseInt(match[2], 10),
        total: parseInt(match[3], 10),
      };
    }
    return { from: 1, to: 10, total: 10 };
  }

  async setRowsPerPage(count: number): Promise<void> {
    await this.rowsPerPageSelect.selectOption(String(count));
  }

  async nextPage(): Promise<void> {
    await this.nextPageButton.click();
  }

  async prevPage(): Promise<void> {
    await this.prevPageButton.click();
  }

  async waitForToast(pattern: string | RegExp): Promise<string> {
    const toast = this.page.locator('[role="alert"], .toast, .chakra-toast, .ant-notification-notice');
    const matched = toast.filter({ hasText: pattern }).first();
    await matched.waitFor({ state: 'visible', timeout: 10_000 });
    return (await matched.innerText()).trim();
  }
}
