# Munshi Invoice Listing Page — Automated UI Testing Agent

> **Source of Truth**: `listing_page_staging_reference.pdf` (origin/staging @ ec431c8)  
> **Deep Understanding Doc**: [`munshi_listing_page_understanding.txt`](file:///home/petpooja/Desktop/UI_tester/munshi_listing_page_understanding.txt)  
> **Master Architecture Plan**: [`munshi_ui_testing_master_plan.md`](file:///home/petpooja/Desktop/UI_tester/munshi_ui_testing_master_plan.md)

---

## 🚀 Overview

This repository houses the complete, production-grade automated UI testing agent for the **Munshi / Tally Automation SaaS Invoice Listing Page**. Built with **Playwright + Cucumber (`playwright-bdd`)** and **TypeScript**, it provides 100% traceability between the PDF specification, Gherkin feature files, and native Playwright browser test executions.

---

## 🔄 What is the Current Flow?

The automated test agent operates across an end-to-end lifecycle designed for speed, isolation, and zero flakiness:

```
┌────────────────────────────────────────────────────────────────────────┐
│                        1. PRE-SCENARIO HOOKS                           │
│  - Load auth token & role permissions (Owner / Accountant / Sub-user)  │
│  - Sanitize localStorage (clear tallyPushDontAskAgain, activeCompanyId)│
│  - Sanitize sessionStorage (clear search & column filter states)       │
└───────────────────────────────────┬────────────────────────────────────┘
                                    │
                                    ▼
┌────────────────────────────────────────────────────────────────────────┐
│                        2. DETERMINISTIC MOCKING                        │
│  - Intercept /api/invoice/list (serve all 8 status states / 55 rows)   │
│  - Mock Tally Push responses (success, Tally validation failures)      │
│  - Intercept bulk actions (mark duplicate, reject, delete endpoints)   │
└───────────────────────────────────┬────────────────────────────────────┘
                                    │
                                    ▼
┌────────────────────────────────────────────────────────────────────────┐
│                        3. PAGE NAVIGATION & POM                        │
│  - Navigate to /listing/invoices                                       │
│  - ListingPage POM initializes Header, Tabs, Filters, Table & Panels   │
│  - Wait for table and header elements to reach visible / idle state    │
└───────────────────────────────────┬────────────────────────────────────┘
                                    │
                                    ▼
┌────────────────────────────────────────────────────────────────────────┐
│                        4. GHERKIN SCENARIO RUN                         │
│  - User actions: tab clicks, client-side search, custom date filters,  │
│    checkbox selections, file upload modal drops, bulk push executions  │
│  - Real-time simulation: dispatch synthetic SSE invoice_status events  │
└───────────────────────────────────┬────────────────────────────────────┘
                                    │
                                    ▼
┌────────────────────────────────────────────────────────────────────────┐
│                        5. SMART ASSERTIONS                             │
│  - Verify badge text & colors (Purchase blue, Sales green, Exp purple) │
│  - Check dynamic push button labels & multi-page selection counts      │
│  - Verify error toasts and guard dialogs (e.g. 51+ files guard check)  │
│  - Smart polling with .toPass() instead of arbitrary sleep timeouts    │
└───────────────────────────────────┬────────────────────────────────────┘
                                    │
                                    ▼
┌────────────────────────────────────────────────────────────────────────┐
│                        6. TEARDOWN & REPORTING                         │
│  - On failure: automatically take full-page screenshots and zip traces │
│  - Clean up test artifacts and reset route handlers                    │
│  - Produce Playwright HTML, JSON, and list reports                     │
└────────────────────────────────────────────────────────────────────────┘
```

---

## ⚙️ How It Works?

The test agent connects behavioral specifications directly to browser automation using four modular layers:

### 1. Specification Layer (Gherkin Feature Files)
- Located under [`features/`](file:///home/petpooja/Desktop/UI_tester/features/).
- Written in standard Gherkin syntax (`Given`, `When`, `Then`, `Examples`).
- Divided into 16 feature files mapping directly to the sections of the PDF (Page Anatomy, Tabs, Filter Bar, Tally Push, Actions Menu, Selection, RBAC, etc.).

### 2. Compilation Engine (`playwright-bdd`)
- When running `npm run bdd:gen`, the `playwright-bdd` compiler scans all `.feature` files and binds each step to its matching TypeScript step definition.
- It generates pure Playwright test files in `.features-gen/features/*.spec.js`.
- You get full Playwright advantages: parallel execution, sharding, browser contexts, trace viewer, and video recordings.

### 3. Step Definitions & Page Object Model (`steps/` and `pages/`)
- **Step Definitions** (`steps/*.steps.ts`): Translate plain English steps into POM actions without writing raw locators in test specs.
- **Page Object Models** (`pages/`):
  - [`ListingPage.ts`](file:///home/petpooja/Desktop/UI_tester/pages/ListingPage.ts): Master page object. Handles tabs, search, selection badges, push triggers, pagination.
  - [`UploadModal.ts`](file:///home/petpooja/Desktop/UI_tester/pages/UploadModal.ts): Single vs Multiple modes, dropzone interactions, voucher type selection.
  - [`PushPanel.ts`](file:///home/petpooja/Desktop/UI_tester/pages/PushPanel.ts): Floating progress panel for live Tally sync tracking.
  - Component POMs: [`Header.ts`](file:///home/petpooja/Desktop/UI_tester/pages/components/Header.ts), [`NotificationBell.ts`](file:///home/petpooja/Desktop/UI_tester/pages/components/NotificationBell.ts), [`TallyConnectionPopup.ts`](file:///home/petpooja/Desktop/UI_tester/pages/components/TallyConnectionPopup.ts), [`DateFilterPopover.ts`](file:///home/petpooja/Desktop/UI_tester/pages/components/DateFilterPopover.ts), [`ActionsMenu.ts`](file:///home/petpooja/Desktop/UI_tester/pages/components/ActionsMenu.ts).

### 4. Mocking & Real-Time Helpers (`helpers/`)
- **Route Interception** ([`mock.helper.ts`](file:///home/petpooja/Desktop/UI_tester/helpers/mock.helper.ts)): Prevents test flakiness by intercepting network calls using `page.route()` and returning fixture data (`fixtures/api/`).
- **SSE Stream Simulation** ([`sse.helper.ts`](file:///home/petpooja/Desktop/UI_tester/helpers/sse.helper.ts)): Emits simulated Server-Sent Events to verify real-time status transitions without waiting for backend queues.
- **Smart Waits** ([`wait.helper.ts`](file:///home/petpooja/Desktop/UI_tester/helpers/wait.helper.ts)): Replaces flaky `waitForTimeout` with reactive assertion polling via `expect().toPass()`.
- **Storage Management** ([`storage.helper.ts`](file:///home/petpooja/Desktop/UI_tester/helpers/storage.helper.ts)): Direct inspection and manipulation of browser `localStorage` and `sessionStorage`.

---

## ▶️ How Can I Execute the Program?

### Step 1: Prerequisites
Ensure Node.js (≥ 18 LTS) and npm are available in your environment:
```bash
node -v   # Should output v18+ or v20+
npm -v    # Should output 9+ or 10+
```
*(If installed in `~/.local/bin`, ensure `export PATH="$HOME/.local/bin:$PATH"` is in your shell).*

### Step 2: Install Dependencies & Browsers
```bash
cd /home/petpooja/Desktop/UI_tester

# Install npm dependencies
npm install

# Install Playwright browser binaries (Chromium)
npx playwright install chromium
```

### Step 3: Generate Test Specs from Feature Files
Run `bddgen` to compile all `.feature` files into `.features-gen/`:
```bash
npm run bdd:gen
```

### Step 4: Run the Test Suites

#### 🎯 Execute by Tag Category
```bash
# 1. Run Smoke tests (@smoke) — fast critical sanity checks
npm run test:smoke

# 2. Run Full Regression suite (@regression) — all 144 scenarios
npm run test:regression

# 3. Run Tally Push tests (@push) — 50-item limit, confirm modal, floating panel
npm run test:push

# 4. Run Upload Dialog tests (@upload) — modes, voucher types, duplicates
npm run test:upload

# 5. Run Filter & Search tests (@filters) — client-side search, date chips, custom ranges
npm run test:filters

# 6. Run RBAC tests (@rbac) — owner, accountant, and restricted permissions
npm run test:rbac

# 7. Run Real-Time SSE tests (@realtime) — live status event updates
npm run test:realtime

# 8. Run Known Gaps tracking (@known-gap) — verifies O1–O11 documented behaviors
npm run test:gaps
```

#### 🖥️ Interactive & Debugging Execution
```bash
# Open interactive Playwright UI Mode (time-travel, visual DOM explorer, live step runner)
npm run test:ui

# Run tests in headed browser (watch the browser live)
npx playwright test --headed

# Run in step-by-step debug mode with Playwright Inspector
npm run test:debug

# Run a specific feature file only
npx playwright test .features-gen/features/07_tally_push_button.feature.spec.js
```

### Step 5: View Test Reports & Traces
After running tests, open the generated HTML report:
```bash
# Launch interactive HTML report
npm run report
```
If a test fails, Playwright automatically records a `.zip` trace in `test-results/`. Inspect it anytime with:
```bash
npx playwright show-trace test-results/<test-folder>/trace.zip
```

---

## 📁 Project Directory Structure

```
UI_tester/
├── features/                     # 16 Gherkin Feature Files (PDF Sections 1 to 18)
│   ├── 01_page_anatomy.feature
│   ├── 02_invoice_types.feature
│   ├── 03_header_controls.feature
│   ├── 04_tally_status_tabs.feature
│   ├── 05_filter_bar.feature
│   ├── 06_actions_menu.feature
│   ├── 07_tally_push_button.feature
│   ├── 08_table_columns.feature
│   ├── 09_status_badges.feature
│   ├── 10_selection_model.feature
│   ├── 11_pagination.feature
│   ├── 12_upload_dialog.feature
│   ├── 13_row_lifecycle.feature
│   ├── 14_rbac_permissions.feature
│   ├── 15_state_persistence.feature
│   └── 16_known_gaps.feature
│
├── pages/                        # Page Object Model (POM)
│   ├── ListingPage.ts            # Primary POM for Invoice Listing
│   ├── UploadModal.ts            # Upload Dialog POM
│   ├── TransferDialog.ts         # Invoice Transfer Modal POM
│   ├── PushPanel.ts              # Floating "Pushing to Tally" Panel POM
│   └── components/
│       ├── Header.ts             # Company Switcher, Bell, Sync, Tally Connection
│       ├── NotificationBell.ts   # Notification center popover
│       ├── TallyConnectionPopup.ts# Live Tally connector status
│       ├── DateFilterPopover.ts  # 4 date types, 6 chips, custom date picker
│       └── ActionsMenu.ts        # Bulk actions (Download, Transfer, Mark Dup, Reject, Delete)
│
├── steps/                        # Step Definitions (TypeScript)
│   ├── common.steps.ts
│   ├── header.steps.ts
│   ├── tabs.steps.ts
│   ├── filter.steps.ts
│   ├── actions.steps.ts
│   ├── push.steps.ts
│   ├── table.steps.ts
│   ├── selection.steps.ts
│   ├── pagination.steps.ts
│   ├── upload.steps.ts
│   ├── lifecycle.steps.ts
│   ├── rbac.steps.ts
│   └── persistence.steps.ts
│
├── helpers/                      # Test Utilities & Mocks
│   ├── api.helper.ts             # REST API client
│   ├── mock.helper.ts            # Network route interception
│   ├── sse.helper.ts             # SSE event stream simulation
│   ├── storage.helper.ts         # localStorage & sessionStorage management
│   └── wait.helper.ts            # Smart polling & wait assertions
│
├── fixtures/                     # Test Data & Mocks
│   ├── api/                      # JSON API mocks (all status states, 55 rows, push responses)
│   ├── invoices/                 # Sample PDF invoices for all 5 voucher modes
│   └── users.ts                  # Persona roles (Owner, Accountant, Data Entry)
│
├── support/
│   ├── fixtures.ts               # Custom test fixtures with BDD bindings
│   ├── hooks.ts                  # Before / After scenario hooks & failure traces
│   ├── tags.ts                   # Standard tagging taxonomy
│   └── world.ts                  # Scenario context types
│
├── .github/workflows/
│   └── ui-tests.yml              # CI/CD Automated Test Pipeline
│
├── playwright.config.ts          # Playwright Test configuration
├── tsconfig.json                 # TypeScript compiler configuration
└── package.json                  # Dependencies & execution scripts
```

---

## 🏷️ Test Tagging Strategy

| Tag | Purpose | Execution Trigger |
|---|---|---|
| `@smoke` | Fast, high-priority critical path tests | Every Pull Request |
| `@regression` | Full comprehensive test matrix (144 tests) | Nightly / Releases |
| `@rbac` | Role-based permission controls | PR & Release |
| `@push` | Tally Push workflow, limits, floating panel | PR & Release |
| `@upload` | Upload modal, single/multi modes, voucher types | PR & Release |
| `@filters` | Search, date filter, multi-criteria filtering | Nightly |
| `@tabs` | 5 Tally status tabs, counts, filter resets | Nightly |
| `@pagination` | Page limits, row count options, clamping | Nightly |
| `@realtime` | SSE stream events and polling fallbacks | Nightly |
| `@known-gap` | Tracks documented quirks & bugs (O1–O11) | Backlog tracking |
